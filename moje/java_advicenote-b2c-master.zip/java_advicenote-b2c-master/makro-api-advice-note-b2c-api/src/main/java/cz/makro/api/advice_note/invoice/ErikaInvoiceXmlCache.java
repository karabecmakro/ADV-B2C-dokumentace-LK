package cz.makro.api.advice_note.invoice;

import cz.makro.api.advice_note.invoice.client.DownloadApi;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;

@Service
@Slf4j
@RequiredArgsConstructor
public class ErikaInvoiceXmlCache {

    private final DownloadApi downloadApi;

    @Value("${invoice.cache-folder}")
    private String cacheFolderPath;

    public byte[] loadFromFolderOrDownload(String id, String countryCode) {
        String filename = id.substring(4) + ".xml";
        Path cachedFile = Path.of(cacheFolderPath, filename);
        if (Files.exists(cachedFile)) {
            log.debug("Loading file, id = {} - reading from cache folder.", id);
            try {
                return Files.readAllBytes(cachedFile);
            } catch (IOException e) {
                log.warn("Loading file, id = {} - cache read failed, will re-download.", id, e);
            }
        }
        log.debug("Loading file, id = {} - downloading.", id);
        try {
            byte[] fileBytes = downloadApi.downloadInvoice(id, filename, countryCode, false);
            try {
                Files.createDirectories(Path.of(cacheFolderPath));
                Files.write(cachedFile, fileBytes);
                log.debug("Loading file, id = {} - saved to cache folder.", id);
            } catch (IOException e) {
                log.warn("Loading file, id = {} - could not save to cache folder.", id, e);
            }
            return fileBytes;
        } catch (HttpServerErrorException | HttpClientErrorException e) {
            log.error("Loading file, id = {} - download error.", id, e);
            return null;
        }
    }
}
