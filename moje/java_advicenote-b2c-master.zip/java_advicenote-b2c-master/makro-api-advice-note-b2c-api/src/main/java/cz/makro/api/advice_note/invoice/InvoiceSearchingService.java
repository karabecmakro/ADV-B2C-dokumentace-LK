package cz.makro.api.advice_note.invoice;

import cz.makro.api.advice_note.base.AdviceNote;
import cz.makro.api.advice_note.base.log.AdviceNoteLog;

import java.util.List;
import java.util.Optional;

public interface InvoiceSearchingService<T extends AdviceNote, L extends AdviceNoteLog> {

    List<T> getAdviceNotesToSearchInvoice();

    Optional<L> getLastSentAdviceNoteLogBy(Long adviceNoteId);

    void invoiceFound(Long adviceNoteId);

    void mposAdviceNoteIdFound(L adviceNoteLog, Long mposAdviceNoteId);
}
