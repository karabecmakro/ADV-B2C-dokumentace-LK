package cz.makro.api.advice_note.api.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveRequestViewModel;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

@ToString
@Getter
@Setter
public class AdviceNoteSaveRequest extends AdviceNoteSaveRequestViewModel {
    @JsonProperty(required = true)
    @NotNull(message = "customerOrderRef cannot be null")
    private Long customerOrderRef;

}
