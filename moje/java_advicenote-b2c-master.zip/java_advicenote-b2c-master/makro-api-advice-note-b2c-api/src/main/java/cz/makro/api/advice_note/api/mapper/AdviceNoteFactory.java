package cz.makro.api.advice_note.api.mapper;

import cz.makro.api.advice_note.api.dto.AdviceNoteSaveRequest;
import cz.makro.api.advice_note.base.AdviceNote;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveRequestViewModel;

public interface AdviceNoteFactory<T extends AdviceNote, R extends AdviceNoteSaveRequest> {

   T createFromRequest(R request, String mposServerUrl);

}
