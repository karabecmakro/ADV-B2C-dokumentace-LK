package cz.makro.api.advice_note.invoice;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDate;

@Table(name = "KOSIK_B2C_INVOICE")
@Entity
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode
public class InvoiceB2C {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "B2C_INVOICE_ID")
    private Long id;
    @Column(name = "B2C_ADVICE_NOTE_ID")
    private Long adviceNoteId;
    private Integer storeNo;
    private Long tillNo;
    private Long invoiceNo;
    private LocalDate invoiceDate;
    private Integer invoiceTime;
    @Column(name = "PACKING_LIST")
    private String packingListNo;

    @Transient
    private Long mposAdviceNoteId;
}
