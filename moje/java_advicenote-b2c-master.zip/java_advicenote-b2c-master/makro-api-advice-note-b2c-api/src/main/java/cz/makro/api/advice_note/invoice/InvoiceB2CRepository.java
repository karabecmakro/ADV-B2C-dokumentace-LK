package cz.makro.api.advice_note.invoice;

import org.springframework.data.jpa.repository.JpaRepository;

public interface InvoiceB2CRepository extends JpaRepository<InvoiceB2C, Long> {
}
