package cz.makro.api.advice_note.invoice;

import lombok.AllArgsConstructor;
import lombok.EqualsAndHashCode;
import lombok.Getter;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

@Getter
@AllArgsConstructor
@EqualsAndHashCode
public class ErikaLoadingData {

    private final String countryCode;
    private final Integer customerNo;
    private final Integer customerStoreNo;
    private final Integer adviceNoteStoreNo;
    private final LocalDate adviceNoteDate;

    @Override
    public String toString() {
        return String.format("ErikaLoadingData: countryCode = %s, customerNo = %d, customerStoreNo = %d, adviceNoteStoreNo = %d, adviceNoteDate = %s", countryCode, customerNo, customerStoreNo, adviceNoteStoreNo, adviceNoteDate.format(DateTimeFormatter.ISO_LOCAL_DATE));
    }
}
