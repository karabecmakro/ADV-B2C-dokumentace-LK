package cz.makro.api.advice_note;

import cz.makro.api.advice_note.client.AdviceNotesApi;
import cz.makro.api.advice_note.invoice.client.ApiClient;
import cz.makro.api.advice_note.invoice.client.DownloadApi;
import cz.makro.api.advice_note.invoice.client.InvoicesApi;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.scheduling.annotation.EnableScheduling;
import org.springframework.web.client.RestClient;
import org.springframework.web.client.RestTemplate;


@SpringBootApplication
@EnableScheduling
@OpenAPIDefinition(
        servers = {
                @Server(url = "/", description = "Default Server URL")
        }
)
public class MakroApiAdviceNoteApplication {

    public static void main(String[] args) {
        SpringApplication.run(MakroApiAdviceNoteApplication.class, args);
    }

    @Bean
    public RestTemplate restTemplate() {
        return new RestTemplate();
    }

    @Bean
    public AdviceNotesApi adviceNotesApi(cz.makro.api.advice_note.client.ApiClient mposApiClient) {
        return new AdviceNotesApi(mposApiClient);
    }

    @Bean
    public cz.makro.api.advice_note.client.ApiClient apiClient(@Value("${mpos.base-path}") String baseUrl, RestClient mposRestClient) {
        cz.makro.api.advice_note.client.ApiClient apiClient = new cz.makro.api.advice_note.client.ApiClient(mposRestClient);
        apiClient.setBasePath(baseUrl);
        return apiClient;
    }

    @Bean
    public InvoicesApi invoicesApi(ApiClient apiClientInvoices) {
        return new InvoicesApi(apiClientInvoices);
    }

    @Bean
    public DownloadApi downloadApi(ApiClient apiClientInvoices) {
        return new DownloadApi(apiClientInvoices);
    }

    @Bean
    public ApiClient apiClientInvoices(@Value("${erika-api.base-path}") String invoicesApiUrl, RestClient erikaRestClient) {
        ApiClient apiClient = new ApiClient(erikaRestClient);
        apiClient.setBasePath(invoicesApiUrl);
        return apiClient;
    }
}
