package cz.makro.api.advice_note.invoice;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import cz.makro.api.advice_note.b2c.AdviceNoteB2C;
import cz.makro.api.advice_note.b2c.log.AdviceNoteB2CLog;
import cz.makro.api.advice_note.base.log.AdviceNoteLog;
import cz.makro.api.advice_note.client.AdviceNotesApi;
import cz.makro.api.advice_note.client.model.AdviceNoteGetResponseViewModel;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.context.event.ApplicationReadyEvent;
import org.springframework.context.event.EventListener;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
@Slf4j
public class InvoiceSearchingExpert {

    private final AdviceNotesApi adviceNotesApi;
    private final ErikaInvoiceDataRepository erikaInvoiceDataRepository;
    private final InvoiceB2CRepository invoiceB2CRepository;
    private final InvoiceSearchingService<AdviceNoteB2C, AdviceNoteB2CLog> invoiceB2CSearchingService;
    private final AtomicBoolean isRunning = new AtomicBoolean(false);

    @Scheduled(cron = "0 0/10 * * * *")
    @EventListener(ApplicationReadyEvent.class)
    public void getInvoiceNoB2C() {
        if (!isRunning.compareAndSet(false, true)) {
            log.info("getInvoiceNoB2C is already running, skipping this execution");
            return;
        }

        try {
            List<AdviceNoteB2C> adviceNotesToSearchInvoice = invoiceB2CSearchingService.getAdviceNotesToSearchInvoice();
            if (adviceNotesToSearchInvoice.isEmpty()) {
                log.info("No adviceNotes to search invoice");
                return;
            }
            for (AdviceNoteB2C adviceNote : adviceNotesToSearchInvoice) {
                AdviceNoteB2CLog lastSentAdviceNoteLog = invoiceB2CSearchingService.getLastSentAdviceNoteLogBy(adviceNote.getId()).get();
                Long lastMposAdviceNoteId = lastSentAdviceNoteLog.getMposAdviceNoteId();
                log.info("Loading invoice (adviceNoteId = {} custBar = {} MPOS AN ID = {})", adviceNote.getId(), adviceNote.getCustomerBarcode(), lastMposAdviceNoteId);

                Optional<String> txNumberOptional = parseHeaderTxNumber(lastSentAdviceNoteLog.getResponse());
                if (txNumberOptional.isEmpty()) {
                    txNumberOptional = parseHeaderTxNumber(lastSentAdviceNoteLog.getRequest());
                    if (txNumberOptional.isEmpty()) {
                        log.info("Loading invoice, txNumber not found (adviceNoteId = {} custBar = {} MPOS AN ID = {} lastSentAdviceNoteLog.resp = {}, lastSentAdviceNoteLog.req = {})", adviceNote.getId(), adviceNote.getCustomerBarcode(), lastMposAdviceNoteId, lastSentAdviceNoteLog.getResponse(), lastSentAdviceNoteLog.getRequest());
                        continue;
                    }
                }
                if (lastSentAdviceNoteLog.getSentTime() == null) {
                    log.info("Loading invoice, lastSentAdviceNoteLog sentTime is null (adviceNoteId = {} custBar = {} MPOS AN ID = {} lastSentAdviceNoteLog.resp = {}, lastSentAdviceNoteLog.req = {})", adviceNote.getId(), adviceNote.getCustomerBarcode(), lastMposAdviceNoteId, lastSentAdviceNoteLog.getResponse(), lastSentAdviceNoteLog.getRequest());
                    continue;
                }
                log.info("Loading invoice (adviceNoteId = {} custBar = {} MPOS AN ID = {} txNumber = {})", adviceNote.getId(), adviceNote.getCustomerBarcode(), lastMposAdviceNoteId, txNumberOptional.orElse(null));

                ErikaLoadingData erikaLoadingData = adviceNoteToErikaLoadingData(adviceNote, lastSentAdviceNoteLog);
                erikaInvoiceDataRepository.prepareData(erikaLoadingData);

                try {
                    Optional<InvoiceB2C> invoiceB2COptional = erikaInvoiceDataRepository.getInvoiceB2C(erikaLoadingData, txNumberOptional.orElse(null));
                    if (invoiceB2COptional.isEmpty()) {
                        log.info("Loading invoice - not found (adviceNoteId = {} custBar = {} MPOS AN ID = {} txNumber = {})", adviceNote.getId(), adviceNote.getCustomerBarcode(), lastMposAdviceNoteId, txNumberOptional.orElse(null));
                        continue;
                    }
                    InvoiceB2C newInvoiceB2C = invoiceB2COptional.get();
                    log.info("Loading invoice (adviceNoteId = {} custBar = {} MPOS AN ID = {} txNumber = {}): FOUND invoiceNo = {}", adviceNote.getId(), adviceNote.getCustomerBarcode(), lastMposAdviceNoteId, txNumberOptional.orElse(null), newInvoiceB2C.getPackingListNo());
                    newInvoiceB2C.setAdviceNoteId(adviceNote.getId());

                    if (lastMposAdviceNoteId == null) {
                        log.info("MPOS AdviceNoteId updated while loading invoice (was not set)");
                        invoiceB2CSearchingService.mposAdviceNoteIdFound(lastSentAdviceNoteLog, newInvoiceB2C.getMposAdviceNoteId());
                    }
                    invoiceB2CRepository.save(newInvoiceB2C);
                    invoiceB2CSearchingService.invoiceFound(adviceNote.getId());
                } catch (Throwable t) {
                    log.error("Error while loading invoice", t);
                }
            }
            log.info("Searching invoice - DONE");
        } finally {
            isRunning.set(false);
        }
    }

    private static ErikaLoadingData adviceNoteToErikaLoadingData(AdviceNoteB2C adviceNoteB2C, AdviceNoteLog lastSentAdviceNoteLog) {
        int adviceNoteStoreNo = Integer.parseInt(adviceNoteB2C.getMposServerUrl().substring(9, 12));//PRG11MPSU012001 -> 12
        String countryCode = adviceNoteStoreNo < 20 ? "CZ" : "SK";
        Integer customerNo = Integer.parseInt(adviceNoteB2C.getCustomerBarcode().substring(3, 9));
        Integer customerStoreNo = Integer.parseInt(adviceNoteB2C.getCustomerBarcode().substring(0, 3));
        LocalDate adviceNoteDate = lastSentAdviceNoteLog.getSentTime().toLocalDate();
        return new ErikaLoadingData(countryCode, customerNo, customerStoreNo, adviceNoteStoreNo, adviceNoteDate);
    }

    public String getAdviceNoteDataBy(String mposServerUrl, String customerBarcode, Long mposAdviceNoteId) {
        ResponseEntity<AdviceNoteGetResponseViewModel> response = adviceNotesApi.getByCustomerAndAdviceNoteWithHttpInfo(mposServerUrl, customerBarcode, mposAdviceNoteId.intValue());
        return response.toString();
    }


    private Optional<String> parseHeaderTxNumber(String response) {
        try {
            if (response == null || response.isEmpty()) {
                return Optional.empty();
            }
            //strip 'status' until
            int firstBraceIndex = response.indexOf('{');
            if (firstBraceIndex == -1) {
                return Optional.empty();
            }
            String jsonString = response.substring(firstBraceIndex);
            ObjectMapper objectMapper = new ObjectMapper();
            JsonNode rootNode = objectMapper.readTree(jsonString);
            JsonNode headerNode = rootNode.get("header");
            if (headerNode != null) {
                JsonNode txNumberNode = headerNode.get("txNumber");
                if (txNumberNode != null) {
                    return Optional.ofNullable(txNumberNode.asText());
                }
            }
            return Optional.empty();
        } catch (Exception e) {
            log.error("Error parsing txNumber from response", e);
            return Optional.empty();
        }
    }
}
