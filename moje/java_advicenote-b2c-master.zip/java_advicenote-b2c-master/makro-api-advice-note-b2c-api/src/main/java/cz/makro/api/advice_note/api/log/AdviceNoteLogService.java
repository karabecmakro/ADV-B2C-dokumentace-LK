package cz.makro.api.advice_note.api.log;

import com.nimbusds.jose.shaded.gson.Gson;
import cz.makro.api.advice_note.base.AdviceNote;
import cz.makro.api.advice_note.base.log.AdviceNoteLog;
import cz.makro.api.advice_note.base.log.AdviceNoteLogRepository;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveRequestViewModel;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveResponseHeaderViewModel;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveResponseViewModel;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;

import java.time.LocalDateTime;
import java.util.Optional;

@RequiredArgsConstructor
public abstract class AdviceNoteLogService<T extends AdviceNote, L extends AdviceNoteLog> {

    private final AdviceNoteLogRepository<L> adviceNoteLoggerRepo;

    public L createAdviceNoteLog(T adviceNote, AdviceNoteSaveRequestViewModel model) {
        L adviceNoteLog = createAdviceNoteLog(adviceNote);
        adviceNoteLog.setRequest(new Gson().toJson(model, AdviceNoteSaveRequestViewModel.class));
        adviceNoteLog = adviceNoteLoggerRepo.save(adviceNoteLog);
        return adviceNoteLog;
    }

    protected abstract L createAdviceNoteLog(T adviceNote);

    public void mapResponseAndSave(L adviceNoteLog, ResponseEntity<AdviceNoteSaveResponseViewModel> response) {
        Optional<AdviceNoteSaveResponseViewModel> optionalBody = Optional.ofNullable(response.getBody());
        adviceNoteLog.setResponse(new Gson().toJson(response.getStatusCode()) + optionalBody.map(body -> new Gson().toJson(body)).orElse(""));
        adviceNoteLog.setMposAdviceNoteId(optionalBody.map(AdviceNoteSaveResponseViewModel::getHeader).map(AdviceNoteSaveResponseHeaderViewModel::getAdviceNoteId).orElse(null));
        adviceNoteLog.setStatusCode(response.getStatusCode().value());
        adviceNoteLog.setSentTime(LocalDateTime.now());
        adviceNoteLog.setErrors(optionalBody.map(AdviceNoteSaveResponseViewModel::getErrors).map(errors -> new Gson().toJson(errors)).orElse(null));

        adviceNoteLoggerRepo.save(adviceNoteLog);
    }

    public abstract Optional<L> getNewestLogBy(Long adviceNoteId);

    public void mposAdviceNoteIdFound(L adviceNoteLog, Long mposAdviceNoteId) {
        adviceNoteLog.setMposAdviceNoteId(mposAdviceNoteId);
        adviceNoteLoggerRepo.save(adviceNoteLog);
    }
}
