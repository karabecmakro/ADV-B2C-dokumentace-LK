package cz.makro.api.advice_note.api.exception_handler;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.BAD_REQUEST)
public class HttpBadAdviceNoteRequest extends RuntimeException{
    public HttpBadAdviceNoteRequest(String message) {
        super(message);
    }
}
