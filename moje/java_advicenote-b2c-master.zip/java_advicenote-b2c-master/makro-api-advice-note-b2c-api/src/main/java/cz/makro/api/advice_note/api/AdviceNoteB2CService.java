package cz.makro.api.advice_note.api;

import cz.makro.api.advice_note.api.dto.AdviceNoteSaveRequest;
import cz.makro.api.advice_note.api.log.AdviceNoteB2CFactory;
import cz.makro.api.advice_note.b2c.AdviceNoteB2C;
import cz.makro.api.advice_note.b2c.AdviceNoteB2CRepository;
import cz.makro.api.advice_note.b2c.log.AdviceNoteB2CLog;
import cz.makro.api.advice_note.api.log.AdviceNoteB2CLogService;
import cz.makro.api.advice_note.client.AdviceNotesApi;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveRequestViewModel;
import org.springframework.stereotype.Service;

@Service
public class AdviceNoteB2CService extends cz.makro.api.advice_note.api.AdviceNoteService<AdviceNoteB2C, AdviceNoteB2CLog, AdviceNoteSaveRequest> {

    public AdviceNoteB2CService(AdviceNoteB2CRepository adviceNoteB2CRepository, AdviceNoteB2CFactory adviceNoteB2CFactory, AdviceNoteB2CLogService adviceNoteB2CLogService, AdviceNotesApi adviceNotesApi) {
        super(adviceNoteB2CRepository, adviceNoteB2CFactory, adviceNoteB2CLogService, adviceNotesApi);
    }

    protected void assertCorrectToDeliveryNote(AdviceNoteB2C adviceNote) {
        //OK, could not assert
    }

    protected void cancelPreviousAdviceNotes(AdviceNoteB2C adviceNote) {
        //OK, could not cancel
    }
}
