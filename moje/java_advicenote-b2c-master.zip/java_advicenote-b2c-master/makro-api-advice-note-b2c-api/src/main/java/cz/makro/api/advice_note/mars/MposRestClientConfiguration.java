package cz.makro.api.advice_note.mars;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.annotation.web.configurers.HeadersConfigurer;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.client.OAuth2ClientHttpRequestInterceptor;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestClient;


import java.util.HashMap;
import java.util.Map;

import static org.springframework.boot.autoconfigure.security.servlet.PathRequest.toH2Console;

@Configuration
@EnableWebSecurity
public class MposRestClientConfiguration {
    //INFO useful for filter chain https://stackoverflow.com/questions/74680244/h2-database-console-not-opening-with-spring-security
    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http.authorizeHttpRequests(authorize -> authorize
                                .anyRequest().permitAll()
                )
                .csrf(csrf -> csrf.ignoringRequestMatchers(toH2Console())).headers(head -> head.
                       frameOptions(HeadersConfigurer.FrameOptionsConfig::sameOrigin))
                .csrf(AbstractHttpConfigurer::disable);
        return http.build();
    }

    @Bean
    public RestClient mposRestClient(OAuth2AuthorizedClientManager mposAuthorizedClientManager) {
        String registrationId = "mpos";
        ClientHttpRequestFactory requestFactory = new JdkClientHttpRequestFactory();
        OAuth2ClientHttpRequestInterceptor requestInterceptor = new OAuth2ClientHttpRequestInterceptor(mposAuthorizedClientManager);
        requestInterceptor.setClientRegistrationIdResolver(request -> registrationId);

        return RestClient.builder()
                .requestFactory(requestFactory)
                .requestInterceptor(requestInterceptor)
                .build();
    }

    @Bean
    public OAuth2AuthorizedClientManager mposAuthorizedClientManager(
            ClientRegistrationRepository clientRegistrationRepository,
            OAuth2AuthorizedClientService authorizedClientService,
            @Value("${client.registration.username}") String username,
            @Value("${client.registration.password}") String password) {

        OAuth2AuthorizedClientProvider authorizedClientProvider =
                OAuth2AuthorizedClientProviderBuilder.builder()
                        .password()
                        .refreshToken()
                        .build();
        AuthorizedClientServiceOAuth2AuthorizedClientManager authorizedClientManager =
                new AuthorizedClientServiceOAuth2AuthorizedClientManager(
                        clientRegistrationRepository, authorizedClientService);
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        authorizedClientManager.setContextAttributesMapper(oAuth2AuthorizeRequest -> {
            if (StringUtils.hasText(username) && StringUtils.hasText(password)) {
                Map<String, Object> contextAttributes = new HashMap<>();


                contextAttributes.put(OAuth2AuthorizationContext.USERNAME_ATTRIBUTE_NAME, username);
                contextAttributes.put(OAuth2AuthorizationContext.PASSWORD_ATTRIBUTE_NAME, password);
                return contextAttributes;
            }
            throw new IllegalArgumentException("Username or password for OAuth2 is null or empty");
        });

        return authorizedClientManager;
    }
}
