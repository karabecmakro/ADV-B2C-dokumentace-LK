package cz.makro.api.advice_note.api.log;

import cz.makro.api.advice_note.api.dto.AdviceNoteSaveRequest;
import cz.makro.api.advice_note.api.mapper.AdviceNoteFactory;
import cz.makro.api.advice_note.api.mapper.AdviceNoteMapper;
import cz.makro.api.advice_note.b2c.AdviceNoteB2C;
import cz.makro.api.advice_note.b2c.AdviceNoteB2CItem;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class AdviceNoteB2CFactory implements AdviceNoteFactory<AdviceNoteB2C, AdviceNoteSaveRequest> {

    public AdviceNoteB2C createFromRequest(AdviceNoteSaveRequest request, String mposServerUrl) {

        AdviceNoteB2C adviceNoteB2C = new AdviceNoteB2C();
        AdviceNoteMapper.mapRequestToAdviceNote(request, adviceNoteB2C, mposServerUrl);

        adviceNoteB2C.setAdviceNoteItems(request.getItems().stream().map(itemViewModel -> AdviceNoteMapper.mapRequestItemToAdviceNoteItem(itemViewModel, new AdviceNoteB2CItem())).collect(Collectors.toList()));
        adviceNoteB2C.setCustomerOrderRef(request.getCustomerOrderRef());

        return adviceNoteB2C;
    }

}
