package cz.makro.api.advice_note.invoice;

import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import cz.makro.api.advice_note.invoice.client.HalWrapper;
import cz.makro.api.advice_note.invoice.client.InvoiceQuery;
import cz.makro.api.advice_note.invoice.client.InvoiceRepresentation;
import cz.makro.api.advice_note.invoice.client.InvoicesApi;
import invoices.demo.summary.client.ADVICENOTEHEADER;
import invoices.demo.summary.client.TAS;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.time.format.DateTimeFormatter;
import java.util.*;

@Service
@Slf4j
@RequiredArgsConstructor
public class ErikaInvoiceDataRepository {

    private final InvoicesApi invoicesApi;
    private final ErikaInvoiceXmlCache xmlCache;

    private final Map<ErikaLoadingData, Map<String, InvoiceB2C>> erikaLoadingDataToTxNumberAndInvoiceData = new HashMap<>();

    private static final ObjectMapper objectMapper;

    static {
        objectMapper = new XmlMapper();
        objectMapper.configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false);
    }

    public Optional<InvoiceB2C> getInvoiceB2C(ErikaLoadingData erikaLoadingData, String mposAdviceNoteTxNumber) {
        return Optional.ofNullable(
                erikaLoadingDataToTxNumberAndInvoiceData
                        .computeIfAbsent(erikaLoadingData, k -> new HashMap<>())
                        .getOrDefault(mposAdviceNoteTxNumber, null)
        );
    }

    public void prepareData(ErikaLoadingData erikaLoadingData) {

        InvoiceQuery invoiceQuery = new InvoiceQuery();
        invoiceQuery.from(erikaLoadingData.getAdviceNoteDate()); //the packing list has the same date as adviceNoteLog
        invoiceQuery.to(erikaLoadingData.getAdviceNoteDate());
        invoiceQuery.setStore(erikaLoadingData.getAdviceNoteStoreNo());
        invoiceQuery.setCustomer(erikaLoadingData.getCustomerNo());
        invoiceQuery.setHomeStore(erikaLoadingData.getCustomerStoreNo());
        invoiceQuery.setType(InvoiceQuery.TypeEnum.PACKINGLIST);

        List<InvoiceRepresentation> invoiceRepresentationList = new ArrayList<>();
        while (true) {
            try {
                HalWrapper halWrapper = invoicesApi.listInvoices(invoiceQuery, erikaLoadingData.getCountryCode(), false, invoiceRepresentationList.size());
                if (halWrapper.getEmbedded() == null || halWrapper.getEmbedded().getItems().isEmpty()) {
                    break;
                } else {
                    invoiceRepresentationList.addAll(halWrapper.getEmbedded().getItems());
                }
            } catch (HttpServerErrorException | HttpClientErrorException httpException) {
                log.error("Loading invoice data from ErikA {}", erikaLoadingData, httpException);
                break;
            }
        }

        for (InvoiceRepresentation item : invoiceRepresentationList) {
            TAS tas;
            try (ByteArrayInputStream inputStream = new ByteArrayInputStream(xmlCache.loadFromFolderOrDownload(item.getId(), erikaLoadingData.getCountryCode()))) {
                log.debug("Loading file, id = {} - parsing.", item.getId());
                tas = objectMapper.readValue(inputStream, TAS.class);
            } catch (IOException | NullPointerException e) {
                log.error("Loading file, id = {} - parse error.", item.getId(), e);
                continue;
            }

            for (ADVICENOTEHEADER adviceNoteHeader : tas.getNEWTA().getADVICENOTEHEADER()) {
                Long mposAdviceNoteId = adviceNoteHeader.getlReceiptNmbr().longValue();
                String mposAdviceNoteTxNumber = adviceNoteHeader.getSzExternalTxNumber();
                String packingListNo = adviceNoteHeader.getSzInvoiceID();

                InvoiceB2C newInvoiceB2C = new InvoiceB2C();
                newInvoiceB2C.setStoreNo(item.getNumber().getStore());
                newInvoiceB2C.setTillNo(item.getNumber().getTill().longValue());
                newInvoiceB2C.setInvoiceNo(item.getNumber().getSequenceNr().longValue());
                newInvoiceB2C.setInvoiceDate(item.getCreated().toLocalDate());
                newInvoiceB2C.setInvoiceTime(Integer.parseInt(item.getCreated().toLocalTime().format(DateTimeFormatter.ofPattern("Hmmss"))));
                newInvoiceB2C.setPackingListNo(packingListNo);
                newInvoiceB2C.setMposAdviceNoteId(mposAdviceNoteId);

                erikaLoadingDataToTxNumberAndInvoiceData
                        .computeIfAbsent(erikaLoadingData, k -> new HashMap<>())
                        .computeIfAbsent(mposAdviceNoteTxNumber, k -> newInvoiceB2C);

                log.debug("Loading file, id = {} - done. Loaded mposAdviceNoteId = {}, txNumber = {}, packingListNo = {}", item.getId(), newInvoiceB2C.getMposAdviceNoteId(), mposAdviceNoteTxNumber, newInvoiceB2C.getPackingListNo());
            }
        }
    }

    private String invoiceQueryToStringUsingOnlyNonNullProperties(InvoiceQuery invoiceQuery) {
        if (invoiceQuery == null) {
            return "InvoiceQuery(null)";
        }

        StringBuilder sb = new StringBuilder("InvoiceQuery(");
        List<String> properties = new ArrayList<>();

        if (invoiceQuery.getFrom() != null) {
            properties.add("from=" + invoiceQuery.getFrom());
        }
        if (invoiceQuery.getTo() != null) {
            properties.add("to=" + invoiceQuery.getTo());
        }
        if (invoiceQuery.getStore() != null) {
            properties.add("store=" + invoiceQuery.getStore());
        }
        if (invoiceQuery.getCustomer() != null) {
            properties.add("customer=" + invoiceQuery.getCustomer());
        }
        if (invoiceQuery.getHomeStore() != null) {
            properties.add("homeStore=" + invoiceQuery.getHomeStore());
        }
        if (invoiceQuery.getType() != null) {
            properties.add("type=" + invoiceQuery.getType());
        }

        sb.append(String.join("&", properties));
        sb.append(")");

        return sb.toString();
    }
}
