package cz.makro.api.advice_note.api;

import cz.makro.api.advice_note.api.dto.AdviceNoteSaveRequest;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveResponseViewModel;
import cz.makro.api.advice_note.invoice.InvoiceSearchingExpert;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.enums.ParameterIn;
import io.swagger.v3.oas.annotations.enums.ParameterStyle;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.ExampleObject;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
@Validated
public class AdviceNoteController {

    private final AdviceNoteB2CService adviceNoteB2CService;
    private final InvoiceSearchingExpert invoiceSearchingExpert;

    @Operation(
            summary = "Creates a new AdviceNote, MARS's API copy",
            description = "Sends a request to create a new AdviceNote",
            parameters = {
                    @Parameter(in = ParameterIn.PATH, name = "mposServerUrl", required = true, style = ParameterStyle.SIMPLE, example = "PRG11MPSU006001")
            },
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "AdviceNote in form of JSON",
                    content = @Content(
                            examples = @ExampleObject(
                                    name = "Example request",
                                    externalValue = "{json-example}" //TODO add JSON example testing data
                            )
                    )
            )
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "Success"),
            @ApiResponse(responseCode = "201", description = "Successfully created"),
            @ApiResponse(responseCode = "400", description = "Input was wrong"),
            @ApiResponse(responseCode = "404", description = "Not found"),
            @ApiResponse(responseCode = "406", description = "Input data caused a database error"),
            @ApiResponse(responseCode = "409", description = "Conflict")
    })
    @PostMapping({
            "/api/{mposServerUrl}/AdviceNotes",
            "/api/{mposServerUrl}/AdviceNotes/"
    })
    public ResponseEntity<AdviceNoteSaveResponseViewModel> postRequestViewModel(@PathVariable String mposServerUrl, @RequestBody @Valid AdviceNoteSaveRequest model) {
        return adviceNoteB2CService.postAdviceNote(mposServerUrl, model);
    }

    @Operation(
            summary = "Resends an adviceNote based on id",
            description = "Resends an adviceNote found by the Id",
            parameters = {
                    @Parameter(in = ParameterIn.PATH, name = "mposServerUrl", required = true, style = ParameterStyle.SIMPLE, example = "PRG11MPSU006001"),
                    @Parameter(in = ParameterIn.PATH, name = "adviceNoteId", required = true, style = ParameterStyle.SIMPLE, example = "123456")
            },
            requestBody = @io.swagger.v3.oas.annotations.parameters.RequestBody(
                    description = "AdviceNote in form of JSON",
                    content = @Content(
                            examples = @ExampleObject(
                                    name = "Example request",
                                    externalValue = "{json-example}" //TODO add JSON example testing data
                            )
                    )
            )
    )
    @ApiResponses(value = {
            @ApiResponse(responseCode = "200", description = "AdviceNote was successfully resend"),
            @ApiResponse(responseCode = "400", description = "There was an error with the input"),
    })
    @PostMapping("/api/{mposServerUrl}/AdviceNotes/{adviceNoteId}/resend")
    @Hidden
    public ResponseEntity<AdviceNoteSaveResponseViewModel> resendAdviceNote(@PathVariable String mposServerUrl, @PathVariable Long adviceNoteId) {
        return adviceNoteB2CService.resendAdviceNote(mposServerUrl, adviceNoteId);
    }

    @Hidden
    @GetMapping("/api/{mposServerUrl}/AdviceNotes/{adviceNoteId}/test")
    @PostMapping("/api/{mposServerUrl}/AdviceNotes/{adviceNoteId}/test")
    public ResponseEntity<String> test(@PathVariable String mposServerUrl, @PathVariable Long adviceNoteId) {
        return ResponseEntity.ok("Test call successfull. Params: mposServerUrl=" + mposServerUrl + " adviceNoteId=" + adviceNoteId);
    }

    @Hidden
    @GetMapping("/api/{mposServerUrl}/CustomerBarcode/{customerBarcode}/AdviceNotes/{adviceNoteId}/invoice")
    public ResponseEntity<String> invoice(@PathVariable String mposServerUrl, @PathVariable String customerBarcode, @PathVariable Long adviceNoteId) {
        return ResponseEntity.ok(invoiceSearchingExpert.getAdviceNoteDataBy(mposServerUrl, customerBarcode, adviceNoteId));
    }
}
