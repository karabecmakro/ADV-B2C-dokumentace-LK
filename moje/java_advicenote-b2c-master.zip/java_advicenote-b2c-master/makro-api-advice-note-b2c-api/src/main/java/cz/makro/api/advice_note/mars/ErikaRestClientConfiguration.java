package cz.makro.api.advice_note.mars;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.ClientHttpRequestFactory;
import org.springframework.http.client.JdkClientHttpRequestFactory;
import org.springframework.security.oauth2.client.*;
import org.springframework.security.oauth2.client.registration.ClientRegistrationRepository;
import org.springframework.security.oauth2.client.web.client.OAuth2ClientHttpRequestInterceptor;
import org.springframework.web.client.RestClient;

@Configuration
public class ErikaRestClientConfiguration {

    @Bean
    public OAuth2AuthorizedClientManager erikaAuthorizedClientManager(
            ClientRegistrationRepository clientRegistrationRepository
            , OAuth2AuthorizedClientService authorizedClientService
    ) {
        OAuth2AuthorizedClientProvider authorizedClientProvider
                = OAuth2AuthorizedClientProviderBuilder.builder()
                .clientCredentials()
                .build();

        AuthorizedClientServiceOAuth2AuthorizedClientManager authorizedClientManager
                = new AuthorizedClientServiceOAuth2AuthorizedClientManager(
                clientRegistrationRepository, authorizedClientService
        );
        authorizedClientManager.setAuthorizedClientProvider(authorizedClientProvider);

        return authorizedClientManager;
    }

    @Bean
    public RestClient erikaRestClient(OAuth2AuthorizedClientManager erikaAuthorizedClientManager) {
        String registrationId = "erika";
        ClientHttpRequestFactory requestFactory = new JdkClientHttpRequestFactory();
        OAuth2ClientHttpRequestInterceptor requestInterceptor = new OAuth2ClientHttpRequestInterceptor(erikaAuthorizedClientManager);
        requestInterceptor.setClientRegistrationIdResolver(request -> registrationId);

        return RestClient.builder()
                .requestFactory(requestFactory)
                .requestInterceptor(requestInterceptor)
                .build();
    }
}