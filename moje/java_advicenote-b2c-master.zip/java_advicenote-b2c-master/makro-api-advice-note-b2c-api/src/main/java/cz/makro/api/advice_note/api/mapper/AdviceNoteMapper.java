package cz.makro.api.advice_note.api.mapper;

import com.nimbusds.jose.shaded.gson.Gson;
import com.nimbusds.jose.shaded.gson.reflect.TypeToken;
import cz.makro.api.advice_note.base.AdviceNote;
import cz.makro.api.advice_note.base.AdviceNoteItem;
import cz.makro.api.advice_note.base.AdviceNoteStatus;
import cz.makro.api.advice_note.client.model.*;
import org.apache.commons.lang3.StringUtils;
import org.springframework.http.HttpEntity;
import org.springframework.http.ResponseEntity;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.util.Optional;

public class AdviceNoteMapper {

    public static void mapRequestToAdviceNote(AdviceNoteSaveRequestViewModel request, cz.makro.api.advice_note.base.AdviceNote adviceNote, String mposServerUrl) {

        Optional<AdviceNoteSaveRequestViewModel> optionalRequest = Optional.ofNullable(request);

        adviceNote.setMposServerUrl(mposServerUrl);
        adviceNote.setRequest(optionalRequest.map(existingRequest -> new Gson().toJson(existingRequest)).orElse(null));
        adviceNote.setCustomerBarcode(optionalRequest.map(AdviceNoteSaveRequestViewModel::getCustomer).map(AdviceNoteSaveRequestCustomerViewModel::getCustomerBarcode).orElse(null));
        adviceNote.setHeaderTxNumber(optionalRequest.map(AdviceNoteSaveRequestViewModel::getHeader).map(AdviceNoteSaveRequestHeaderViewModel::getTxNumber).orElse(null));
        adviceNote.setHeaderRequestSource(optionalRequest.map(AdviceNoteSaveRequestViewModel::getHeader).map(AdviceNoteSaveRequestHeaderViewModel::getRequestSource).orElse(null));
        adviceNote.setRequestTimeStamp(LocalDateTime.now());
        adviceNote.setStatus(AdviceNoteStatus.NEW);
    }

    public static void mapResponseToAdviceNote(ResponseEntity<AdviceNoteSaveResponseViewModel> response, AdviceNote adviceNote, AdviceNoteStatus adviceNoteStatus) {
        Integer operatorId = Optional.ofNullable(response).map(HttpEntity::getBody).map(AdviceNoteSaveResponseViewModel::getHeader).map(AdviceNoteSaveResponseHeaderViewModel::getOperatorId).orElse(null);
        adviceNote.setOperatorId(operatorId);
        adviceNote.setResponse(new Gson().toJson(response, new TypeToken<ResponseEntity<AdviceNoteSaveResponseViewModel>>() {
        }.getType()));
        adviceNote.setResponseTimeStamp(LocalDateTime.now());
        adviceNote.setStatus(adviceNoteStatus);
    }

    public static <T extends AdviceNoteItem> T mapRequestItemToAdviceNoteItem(AdviceNoteSaveRequestItemViewModel itemViewModel, T adviceNoteItem) {
        adviceNoteItem.setSequenceNumber(itemViewModel.getSequenceNumber());
        adviceNoteItem.setBarcodeOrGtin(itemViewModel.getBarcodeOrGtin());
        adviceNoteItem.setGtin(itemViewModel.getGtin());
        adviceNoteItem.setLotNumber(itemViewModel.getLotNumber());
        adviceNoteItem.setBarcode(itemViewModel.getBarcode());
        adviceNoteItem.setQuantity(Optional.ofNullable(itemViewModel.getQuantity()).map(BigDecimal::new).orElse(null));
        adviceNoteItem.setWeight(Optional.ofNullable(itemViewModel.getWeight()).map(BigDecimal::new).orElse(null));
        adviceNoteItem.setExternalBarcode(itemViewModel.getExternalBarcode());
        adviceNoteItem.setSzArticleDetails(itemViewModel.getSzArticleDetails() == null ? null : StringUtils.abbreviate(new Gson().toJson(itemViewModel.getSzArticleDetails()), 4000));

        return adviceNoteItem;
    }
}
