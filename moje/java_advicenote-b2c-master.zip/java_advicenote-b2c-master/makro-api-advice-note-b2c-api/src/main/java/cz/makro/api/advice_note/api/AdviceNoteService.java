package cz.makro.api.advice_note.api;

import com.nimbusds.jose.shaded.gson.Gson;
import cz.makro.api.advice_note.api.dto.AdviceNoteSaveRequest;
import cz.makro.api.advice_note.api.exception_handler.HttpBadAdviceNoteRequest;
import cz.makro.api.advice_note.api.log.AdviceNoteLogService;
import cz.makro.api.advice_note.api.mapper.AdviceNoteFactory;
import cz.makro.api.advice_note.api.mapper.AdviceNoteMapper;
import cz.makro.api.advice_note.base.AdviceNote;
import cz.makro.api.advice_note.base.AdviceNoteRepository;
import cz.makro.api.advice_note.base.AdviceNoteStatus;
import cz.makro.api.advice_note.base.log.AdviceNoteLog;
import cz.makro.api.advice_note.client.AdviceNotesApi;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveRequestItemViewModel;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveRequestViewModel;
import cz.makro.api.advice_note.client.model.AdviceNoteSaveResponseViewModel;
import cz.makro.api.advice_note.invoice.InvoiceSearchingService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.client.HttpClientErrorException;
import org.springframework.web.client.HttpServerErrorException;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.temporal.ChronoUnit;
import java.util.List;
import java.util.Optional;
import java.util.Random;

@Slf4j
@RequiredArgsConstructor
public abstract class AdviceNoteService<T extends AdviceNote, L extends AdviceNoteLog, R extends AdviceNoteSaveRequest> implements InvoiceSearchingService<T, L> {

    private final AdviceNoteRepository<T> adviceNoteRepository;
    private final AdviceNoteFactory<T, R> adviceNoteFactory;
    private final AdviceNoteLogService<T, L> adviceNoteLogService;
    private final AdviceNotesApi adviceNotesApi;

    public ResponseEntity<AdviceNoteSaveResponseViewModel> postAdviceNote(String mposServerUrl, R model) {
        //strip numbers before parsing/mapping/saving
        for (AdviceNoteSaveRequestItemViewModel item : model.getItems()) {
            item.setQuantity(Optional.ofNullable(item.getQuantity()).map(String::strip).orElse(null));
            item.setWeight(Optional.ofNullable(item.getWeight()).map(String::strip).orElse(null));
        }

        validateAdviceNoteSaveRequest(model);

        T adviceNote = adviceNoteFactory.createFromRequest(model, mposServerUrl);
        cancelPreviousAdviceNotes(adviceNote);
        adviceNote = adviceNoteRepository.save(adviceNote);

        assertCorrectToDeliveryNote(adviceNote);

        ResponseEntity<AdviceNoteSaveResponseViewModel> response = tryPost(adviceNote, model);
        adviceNoteRepository.save(adviceNote);
        return response;
    }

    public ResponseEntity<AdviceNoteSaveResponseViewModel> resendAdviceNote(String mposServerUrl, Long id) {
        T adviceNote = adviceNoteRepository.findById(id).orElseThrow(() -> new HttpBadAdviceNoteRequest("Advice note id could not be found"));

        AdviceNoteSaveRequest model = new Gson().fromJson(adviceNote.getRequest(), AdviceNoteSaveRequest.class);
        model.getHeader().setTxNumber(getRandomTxNumber());

        assertCorrectToDeliveryNote(adviceNote);

        ResponseEntity<AdviceNoteSaveResponseViewModel> response = tryPost(adviceNote, model);
        adviceNoteRepository.save(adviceNote);
        if (!response.getStatusCode().is2xxSuccessful()) {
            throw new HttpBadAdviceNoteRequest("Response was not successfully send. Response status was: " + response.getStatusCode());
        }
        return response;
    }

    @Override
    public List<T> getAdviceNotesToSearchInvoice() {
        return adviceNoteRepository.findAllByStatusAndRequestTimeStampAfter(AdviceNoteStatus.MARS_ACCEPTED, LocalDateTime.now().minusDays(7).truncatedTo(ChronoUnit.DAYS));
    }

    @Override
    public Optional<L> getLastSentAdviceNoteLogBy(Long adviceNoteId) {
        return adviceNoteLogService.getNewestLogBy(adviceNoteId);
    }

    @Override
    public void invoiceFound(Long adviceNoteId) {
        Optional<T> optionalAdviceNote = adviceNoteRepository.findById(adviceNoteId);
        optionalAdviceNote.ifPresent(adviceNote -> {
            adviceNote.setStatus(AdviceNoteStatus.INVOICE_FOUND);
            adviceNoteRepository.save(adviceNote);
        });
    }

    @Override
    public void mposAdviceNoteIdFound(L adviceNoteLog, Long mposAdviceNoteId) {
        adviceNoteLogService.mposAdviceNoteIdFound(adviceNoteLog, mposAdviceNoteId);
    }

    protected abstract void assertCorrectToDeliveryNote(T adviceNote);

    protected abstract void cancelPreviousAdviceNotes(T adviceNote);

    private String getRandomTxNumber() {
        int length = 32;
        Random r = new Random();
        StringBuilder sb = new StringBuilder();
        while (sb.length() < length) {
            sb.append(Integer.toHexString(r.nextInt()).toUpperCase());
        }
        return sb.substring(0, length);
    }

    private void validateAdviceNoteSaveRequest(AdviceNoteSaveRequestViewModel adviceNoteSaveRequest) {
        for (AdviceNoteSaveRequestItemViewModel item : adviceNoteSaveRequest.getItems()) {
            isParseableAsBigDecimal(item.getQuantity(), "Quantity (item sequenceNumber = " + item.getSequenceNumber() + ")");
            isParseableAsBigDecimal(item.getWeight(), "Weight (item sequenceNumber = " + item.getSequenceNumber() + ")");
        }
    }

    private void isParseableAsBigDecimal(String value, String propertyNameToUseInErrorMessage) {
        try {
            if (value == null) {
                return;
            }
            new BigDecimal(value);
        } catch (NumberFormatException numberFormatException) {
            throw new HttpBadAdviceNoteRequest(propertyNameToUseInErrorMessage + " has to be decimal number. Sent quantity = \"" + value + "\"). " + numberFormatException.getMessage());
        }
    }

    private ResponseEntity<AdviceNoteSaveResponseViewModel> tryPost(T adviceNote, AdviceNoteSaveRequestViewModel model) {
        L adviceNoteLog = adviceNoteLogService.createAdviceNoteLog(adviceNote, model);

        ResponseEntity<AdviceNoteSaveResponseViewModel> response;
        AdviceNoteStatus status;
        try {
            response = adviceNotesApi.postWithHttpInfo(adviceNote.getMposServerUrl(), model);
            status = AdviceNoteStatus.MARS_ACCEPTED;
        } catch (HttpClientErrorException | HttpServerErrorException e) {
            if(e instanceof HttpServerErrorException.GatewayTimeout
            || e instanceof HttpClientErrorException.NotAcceptable) {
                log.error("Error while sending AdviceNote to MARS. {}", e.getMessage());
            } else{
                log.error("Error while sending AdviceNote to MARS.", e);
            }
            response = new ResponseEntity<>(e.getResponseBodyAs(AdviceNoteSaveResponseViewModel.class), e.getStatusCode());
            status = AdviceNoteStatus.MARS_REJECTED;
        }
        AdviceNoteMapper.mapResponseToAdviceNote(response, adviceNote, status);

        adviceNoteLogService.mapResponseAndSave(adviceNoteLog, response);
        return response;
    }
}
