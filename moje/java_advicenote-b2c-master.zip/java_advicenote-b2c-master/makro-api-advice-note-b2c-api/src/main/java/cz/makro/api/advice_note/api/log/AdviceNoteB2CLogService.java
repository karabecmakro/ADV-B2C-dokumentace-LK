package cz.makro.api.advice_note.api.log;

import cz.makro.api.advice_note.b2c.AdviceNoteB2C;
import cz.makro.api.advice_note.b2c.log.AdviceNoteB2CLog;
import cz.makro.api.advice_note.b2c.log.AdviceNoteB2CLogRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class AdviceNoteB2CLogService extends AdviceNoteLogService<AdviceNoteB2C, AdviceNoteB2CLog> {

    private final AdviceNoteB2CLogRepository adviceNoteB2CLogRepository;

    public AdviceNoteB2CLogService(AdviceNoteB2CLogRepository adviceNoteB2CLogRepository) {
        super(adviceNoteB2CLogRepository);
        this.adviceNoteB2CLogRepository = adviceNoteB2CLogRepository;
    }

    public AdviceNoteB2CLog createAdviceNoteLog(AdviceNoteB2C adviceNote) {
        return new AdviceNoteB2CLog(adviceNote.getId());
    }

    @Override
    public Optional<AdviceNoteB2CLog> getNewestLogBy(Long adviceNoteId) {
        return adviceNoteB2CLogRepository.findFirstByAdviceNoteIdOrderBySentTimeDesc(adviceNoteId);
    }
}
