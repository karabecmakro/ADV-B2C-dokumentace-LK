package cz.makro.api.advice_note.mars;

import cz.makro.api.advice_note.client.AdviceNotesApi;
import cz.makro.api.advice_note.client.model.*;
import lombok.extern.slf4j.Slf4j;
import org.junit.Test;
import org.junit.jupiter.api.Assertions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;
import org.springframework.test.context.ActiveProfiles;

import java.util.List;

@SpringBootTest
@Slf4j
@ActiveProfiles("LOCAL")
public class AdviceNotesApiTest {

    @Autowired
    AdviceNotesApi adviceNotesApi;

    private static final String MPOS_SERVER_URL = "PRG11MPSU006001";

    @Test
    public void TC1a() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("44444", "5.000", "00001", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));

        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);

        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TC1b() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList(null, "1.000", "00001", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1B").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TC2a() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList(null, "2.000", "00001", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C2A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TC2b() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("20040409500002", "2.000", "00001", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TC3a() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList(null, "3.000", "00001", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C3A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TC3b() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList(null, "5.000", "00001", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TCX_x() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("2851030000007", "1.000", "00001",
                "3.14", "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void TCX_y() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("2812798022458", "1.000", "00001", "3.14", "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void Scenario01() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("21205804", "1.25", "", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void Scenario02() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("21205804", null, null,
                "1.25", "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    @Test
    public void Scenario03() {
        AdviceNoteSaveRequestViewModel viewModel = new AdviceNoteSaveRequestViewModel();
        viewModel.setItems(createOneItemList("22592118", "3", "", "0",
                "", "", "", "", ""));
        viewModel.setHeader(new AdviceNoteSaveRequestHeaderViewModel().txNumber("0022485B705D1EEE85B1A93975F250C1A").requestSource("KOSIK"));
        viewModel.setCustomer(new AdviceNoteSaveRequestCustomerViewModel().customerBarcode("006268153"));
        ResponseEntity<AdviceNoteSaveResponseViewModel> response = adviceNotesApi.postWithHttpInfo(MPOS_SERVER_URL, viewModel);
        AdviceNoteSaveResponseViewModel responseBody = response.getBody();
        Assertions.assertNotNull(responseBody);
        log.info(responseBody.toString());
    }

    public static List<AdviceNoteSaveRequestItemViewModel> createOneItemList(String barcode, String quantity,
                                                                             String sequenceNumber, String weight,
                                                                             String barCodeOrGtin, String gtin, String lotNumber,
                                                                             String externalNumber, String szArticleDetails) {
        return List.of(
                new AdviceNoteSaveRequestItemViewModel()
                        .sequenceNumber(sequenceNumber)
                        .barcodeOrGtin(barCodeOrGtin)
                        .gtin(gtin)
                        .lotNumber(lotNumber)
                        .barcode(barcode)
                        .quantity(quantity)
                        .weight(weight)
                        .externalBarcode(externalNumber)
                        .szArticleDetails(szArticleDetails)
        );
    }
}
