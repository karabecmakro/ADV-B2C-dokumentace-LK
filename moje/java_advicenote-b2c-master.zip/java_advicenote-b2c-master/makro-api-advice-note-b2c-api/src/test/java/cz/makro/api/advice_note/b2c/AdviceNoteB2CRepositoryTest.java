package cz.makro.api.advice_note.b2c;

import cz.makro.api.advice_note.base.AdviceNoteStatus;
import lombok.extern.slf4j.Slf4j;
import org.junit.Assert;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.context.junit4.SpringRunner;

import java.time.LocalDateTime;

@SpringBootTest
@RunWith(SpringRunner.class)
@Slf4j
@ActiveProfiles("LOCAL")
public class AdviceNoteB2CRepositoryTest {

    @Autowired
    AdviceNoteB2CRepository adviceNoteB2CRepository;

    @Test
    public void testSaveAndLoad() {

        AdviceNoteB2C adviceNote = new AdviceNoteB2C();
        adviceNote.setHeaderTxNumber("TX NO.");
        adviceNote.setHeaderRequestSource("KOSIK");
        adviceNote.setCustomerBarcode("060606");
        adviceNote.setStatus(AdviceNoteStatus.CANCELED);
        adviceNote.setRequest("{\"key\":\"request\"}");
        adviceNote.setRequestTimeStamp(LocalDateTime.now());
        adviceNote.setResponse("{\"key\":\"response\"}");
        adviceNote.setResponseTimeStamp(LocalDateTime.now().plusHours(1));

        AdviceNoteB2C savedAdviceNote = adviceNoteB2CRepository.save(adviceNote);

        Assert.assertNotNull(savedAdviceNote.getId());
    }
}
