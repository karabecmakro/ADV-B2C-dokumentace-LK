package cz.makro.api.advice_note.invoice;

import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.ActiveProfiles;

import java.time.LocalDate;
import java.time.Month;
import java.util.Set;

@SpringBootTest
@ActiveProfiles({"LOCAL"})
@Slf4j
class ErikaInvoiceDataRepositoryTest {

    @Autowired
    ErikaInvoiceDataRepository erikaInvoiceDataRepository;

    @Test
    public void prepareDataTest() {
        ErikaLoadingData erikaLoadingData = new ErikaLoadingData("CZ", 295790, 7, 7, LocalDate.of(2026, Month.JANUARY, 21));
        erikaInvoiceDataRepository.prepareData(erikaLoadingData);
        Assertions.assertNotNull(erikaInvoiceDataRepository.getInvoiceB2C(erikaLoadingData, "HTxnqiwPH9C91tmhHmZGpg=="));
        Assertions.assertNotNull(erikaInvoiceDataRepository.getInvoiceB2C(erikaLoadingData, "HTxnqiwPH9C91wzAHcpDDA=="));

    }

}