# Basic premise
* Client sends a request
* Request gets validated
* Api accepts request
* Request gets saved into a db
* Request gets sent to a Server
* Server validates the client's request with our credentials
* Receive response
* Save response into the db (Ensure error handling)
* Send back response to the client
### Api context
* This Application works as a mediator(essentially sends messages from user to the serve) between the client and server
* Components and connections to the server are generated from swagger.json
* Generated files are automatically generated upon build whist also being tagged as a resource
* This application uses these generated components in order to create endpoints for the user
* When user uses this app's end points the application processes the data from the user
* Processed data is then send to the server which further validates and checks the data
* This application then proceeds to send the response to the user whilst keeping logs of most of the communication
# Diagrams
### Sequence diagram
```mermaid
sequenceDiagram
    title Communication sequence diagram
    participant Client
    participant Api
    participant Server
    Client->>Api: send request
    Api->>Api: validate request
    Api->>Api: save adviceNote (NEW)
    Api->>Api: validated adviceNote
    Api->>Api: save adviceNote (VALID/INVALID)
    Api->>Api: save request to log
    Api->>Server: send request Api with credentials
    Server->>Server: validate request
    Server->>Api: send response
    Api->>Api: save adviceNote response (MARS ACCEPTED/REJECTED)
    Api->>Api: save response to log
    Api->>Client: send response
```
# Important additions and information
### Generated files
* make sure to exclude openapi/src/main/java/cz.makro.api.advice_note.server.api from your project
(in intellij right click exclude)
### Additions to the swagger json file

* Added SecurityDefinitions for OAUTH2.0 
* Added Security for implicitFlow generation inside code
* Edited the path /api/AdviceNotes to /api/{mposServerUrl}/AdviceNotes in order for the API to connect to the right server
* that mposServerUrl can be edited in the yaml file
# Docs

### Reference Documentation

For further reference, please consider the following sections:

* [Official Apache Maven documentation](https://maven.apache.org/guides/index.html)
* [Spring Boot Maven Plugin Reference Guide](https://docs.spring.io/spring-boot/docs/3.1.1/maven-plugin/reference/html/)
* [Create an OCI image](https://docs.spring.io/spring-boot/docs/3.1.1/maven-plugin/reference/html/#build-image)
* [Spring Boot DevTools](https://docs.spring.io/spring-boot/docs/3.1.1/reference/htmlsingle/#using.devtools)
