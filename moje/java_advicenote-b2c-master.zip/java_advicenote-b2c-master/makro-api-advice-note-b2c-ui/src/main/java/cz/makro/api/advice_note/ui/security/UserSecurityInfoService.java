package cz.makro.api.advice_note.ui.security;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.core.oidc.user.DefaultOidcUser;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.regex.Pattern;

@Service
public class UserSecurityInfoService {

    public final Pattern adminSecurityGroupmatcher;

    public UserSecurityInfoService(@Value("${app.admin-group-regex}") String adminGroupRegex) {
        this.adminSecurityGroupmatcher = Pattern.compile(adminGroupRegex);
    }

    public UsersAuthorities getUserAuthorities() {
        List<String> groupMemberships = getGroupMemberships();
        boolean isAdmin = groupMemberships.stream().anyMatch(string -> adminSecurityGroupmatcher.matcher(string).matches());
        if (isAdmin) {
            return UsersAuthorities.admin();
        }
        Optional<Long> userStoreNoOptional = groupMemberships.stream().filter(string -> SecurityConfiguration.ALLOWED_SECURITY_GROUP_MATCHER.matcher(string).matches()).findFirst().map(string -> Long.parseLong(string.substring(string.indexOf("-") - 3, string.indexOf("-") - 1)));
        if (userStoreNoOptional.isPresent()) {
            return UsersAuthorities.userOfStore(userStoreNoOptional.get());
        }

        throw new IllegalArgumentException("Could not find store from user's (" + getUsername() + ") groups.");
    }

    private List<String> getGroupMemberships() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (List<String>) ((DefaultOidcUser) authentication.getPrincipal()).getClaims().get("group_membership");
    }

    public String getUsername() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication.getName();
    }

    public String getUserFirstNameAndLastName() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return (String) ((DefaultOidcUser) authentication.getPrincipal()).getClaims().get("name");
    }
}
