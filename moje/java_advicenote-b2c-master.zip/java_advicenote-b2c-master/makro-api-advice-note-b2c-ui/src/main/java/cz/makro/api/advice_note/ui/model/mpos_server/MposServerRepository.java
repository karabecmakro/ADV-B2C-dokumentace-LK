package cz.makro.api.advice_note.ui.model.mpos_server;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
class MposServerRepository {

    private final EntityManager entityManager;

    List<String> getMposServerUrls() {
        String sql = "SELECT DISTINCT(MPOS_SERVER_URL) FROM KOSIK_B2C_ADVICE_NOTE";
        Query query = entityManager.createNativeQuery(sql, String.class);
        return (List<String>) query.getResultList();
    }
}
