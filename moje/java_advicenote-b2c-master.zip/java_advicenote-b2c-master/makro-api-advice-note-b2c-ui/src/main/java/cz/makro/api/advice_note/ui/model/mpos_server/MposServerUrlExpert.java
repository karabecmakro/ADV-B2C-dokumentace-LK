package cz.makro.api.advice_note.ui.model.mpos_server;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Optional;

@Service
public class MposServerUrlExpert {

    private final MposServerRepository mposServerRepository;
    private final BiMap<Integer, String> storeNoToMposServerUrlMap;
    private final List<String> mposServerUrlOrdered;

    MposServerUrlExpert(MposServerRepository mposServerRepository) {
        this.mposServerRepository = mposServerRepository;
        this.storeNoToMposServerUrlMap = HashBiMap.create();
        this.mposServerUrlOrdered = new ArrayList<>();
        init();
    }

    private void init() {
        List<String> mposServerUrls = mposServerRepository.getMposServerUrls();

        this.mposServerUrlOrdered.clear();
        this.mposServerUrlOrdered.addAll(mposServerUrls.stream().sorted(Comparator.comparingInt(MposServerUrlExpert::parseStoreNoFromMposServerUrl)).toList());

        this.storeNoToMposServerUrlMap.clear();

        for (String mposServerUrl : mposServerUrls) {
            int storeNo = parseStoreNoFromMposServerUrl(mposServerUrl);
            this.storeNoToMposServerUrlMap.put(storeNo, mposServerUrl);
        }
    }

    public List<String> getMposServerUrlsOrdered() {
        return mposServerUrlOrdered;
    }

    public Optional<Integer> getStoreNo(String mposServerUrl) {
        return Optional.ofNullable(storeNoToMposServerUrlMap.inverse().get(mposServerUrl));
    }

    public Optional<String> getMposServerUrl(int storeNo) {
        return Optional.ofNullable(storeNoToMposServerUrlMap.get(storeNo));
    }

    public static String getArtificialMposServerUrl(Integer storeNo) {
        return "XXX11XXXX" + StringUtils.leftPad(storeNo.toString(), 3, "0") + "001";
    }

    private static Integer parseStoreNoFromMposServerUrl(String mposServerUrl) {
        return Integer.parseInt(mposServerUrl.substring(9, 12));//PRG11MPSU012001 -> 12
    }
}
