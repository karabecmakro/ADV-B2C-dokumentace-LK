package cz.makro.api.advice_note.ui.view;

import com.vaadin.flow.component.UI;
import com.vaadin.flow.component.Unit;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.combobox.ComboBox;
import com.vaadin.flow.component.dependency.CssImport;
import com.vaadin.flow.component.grid.Grid;
import com.vaadin.flow.component.grid.HeaderRow;
import com.vaadin.flow.component.notification.Notification;
import com.vaadin.flow.component.orderedlayout.VerticalLayout;
import com.vaadin.flow.component.textfield.TextField;
import com.vaadin.flow.data.renderer.LocalDateTimeRenderer;
import com.vaadin.flow.data.value.ValueChangeMode;
import com.vaadin.flow.router.AfterNavigationEvent;
import com.vaadin.flow.router.AfterNavigationObserver;
import com.vaadin.flow.router.Route;
import cz.makro.api.advice_note.b2c.AdviceNoteB2C;
import cz.makro.api.advice_note.base.AdviceNoteStatus;
import cz.makro.api.advice_note.ui.model.mpos_server.MposServerUrlExpert;
import cz.makro.api.advice_note.ui.resending.ResendingService;
import cz.makro.api.advice_note.ui.model.MarsStatusUtils;
import cz.makro.api.advice_note.ui.model.OverviewDAO;
import cz.makro.api.advice_note.ui.model.OverviewDaoRepository;
import cz.makro.api.advice_note.ui.security.UserSecurityInfoService;
import cz.makro.api.advice_note.ui.security.UsersAuthorities;
import cz.makro.api.advice_note.ui.view.components.DatePickerCZ;
import cz.makro.api.advice_note.ui.view.components.JsonSideDialog;
import jakarta.annotation.security.PermitAll;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;
import java.util.Objects;
import java.util.stream.Stream;

@Route
@PermitAll
@CssImport(
        themeFor = "vaadin-grid",
        value = "./themes/makro-theme/components/vaadin-grid.css"
)
public class OverviewView extends VerticalLayout implements AfterNavigationObserver {

    private final OverviewDaoRepository repository;
    private final MposServerUrlExpert mposServerUrlExpert;

    private final ComboBox<String> customerBarcodeSelect;
    private final TextField customerOrderRefFilter;
    private final ComboBox<String> storeNoSelect;
    private final ComboBox<AdviceNoteStatus> statusSelect;
    private final TextField mposAdviceNoteIdFilter;
    private final TextField invoiceNoFilter;
    private final TextField packingListNoFilter;
    private final DatePickerCZ requestTimestampFilter;
    private final DatePickerCZ lastSentTimeFilter;
    private final DatePickerCZ invoiceDateTimeFilter;

    private final Grid<OverviewDAO> grid;

    private List<OverviewDAO> all;

    private boolean updatingFromUrl = false;

    private final UsersAuthorities userAuthorities;

    private static final String DATE_TIME_FORMAT = "d.M.yyyy HH:mm";

    public OverviewView(OverviewDaoRepository repository, ResendingService resendingService, ResendingService resendingService1, MposServerUrlExpert mposServerUrlExpert, UserSecurityInfoService userSecurityInfoService) {
        this.repository = repository;
        this.mposServerUrlExpert = mposServerUrlExpert;
        userAuthorities = userSecurityInfoService.getUserAuthorities();

        //TODO - zkontrolovat co je číslo faktury a AN vzhledem k ERIK-A
        grid = new Grid<>();
        grid.addColumn(OverviewDAO::getId).setHeader("ID");
        Grid.Column<OverviewDAO> customerBarcodeColumn = grid.addColumn(OverviewDAO::getCustomerBarcode).setHeader("Číslo zákazníka");
        Grid.Column<OverviewDAO> customerOrderRefColumn = grid.addColumn(OverviewDAO::getCustomerOrderRef).setHeader("Číslo objednávky zák.");
        Grid.Column<OverviewDAO> storeNoColumn = grid.addColumn(overviewDAO -> mposServerUrlExpert.getStoreNo(overviewDAO.getMposServerUrl()).orElse(null)).setHeader("Číslo obchodu");
        Grid.Column<OverviewDAO> requestTimestampColumn = grid.addColumn(new LocalDateTimeRenderer<>(OverviewDAO::getRequestTimeStamp, DATE_TIME_FORMAT)).setHeader("Přijetí AN z Košíku");
        Grid.Column<OverviewDAO> lastSentTimeColumn = grid.addColumn(new LocalDateTimeRenderer<>(OverviewDAO::getLastSentTime, DATE_TIME_FORMAT)).setHeader("Poslední odeslání do MPOS");
        Grid.Column<OverviewDAO> statusColumn = grid.addColumn(overviewDAO -> MarsStatusUtils.getTranslation(overviewDAO.getStatus())).setHeader("Stav v MPOS");
        Grid.Column<OverviewDAO> mposAdviceNoteIdColumn = grid.addColumn(OverviewDAO::getLastMposAdviceNoteId).setHeader("MPOS AN ID");
        Grid.Column<OverviewDAO> packingListNoColumn = grid.addColumn(OverviewDAO::getPackingListNo).setHeader("Dodací list");
        Grid.Column<OverviewDAO> invoiceNoColumn = grid.addColumn(OverviewDAO::getInvoiceNo).setHeader("Faktura");
        Grid.Column<OverviewDAO> invoiceDateTimeColumn = grid.addColumn(new LocalDateTimeRenderer<>(OverviewDAO::getInvoiceDateTime, DATE_TIME_FORMAT)).setHeader("Vystavení faktury");
        grid.addComponentColumn(adviceNoteB2C -> {
            Button resenfButton = new Button("Znovu poslat");
            resenfButton.addClickListener(event -> {
                String resentResult = resendingService.resendAdviceNote(adviceNoteB2C);
                resendAndReload();
                Notification.show("Zpráva byla odeslána (" + resentResult + ")");
            });
            boolean buttonDisabled = adviceNoteB2C.getStatus().equals(AdviceNoteStatus.INVOICE_FOUND) || (adviceNoteB2C.getLastSentTime() != null && adviceNoteB2C.getLastSentTime().toLocalDate().isEqual(LocalDate.now()));
            resenfButton.setEnabled(!buttonDisabled);
            return resenfButton;
        }).setHeader("Znovuodeslání");
        grid.addComponentColumn(adviceNoteB2C -> new Button("Požadavek", event -> new JsonSideDialog("Požadavek JSON", adviceNoteB2C.getRequest()).open())).setHeader("Požadavek");
        grid.addComponentColumn(adviceNoteB2C -> new Button("Odpověď", event -> new JsonSideDialog("Odpověď JSON", adviceNoteB2C.getResponse(), JsonSideDialog.IMPORTANT_KEYS_RESPONSE).open())).setHeader("Odpověď");
        grid.addComponentColumn(adviceNoteB2C -> new Button("Data fak.", event -> new JsonSideDialog("Odpověď JSON", resendingService.getAdviceNoteInfo(adviceNoteB2C), true).open())).setHeader("Data fak.");

        grid.getColumns().forEach(overviewDAOColumn -> overviewDAOColumn.setAutoWidth(true));

        grid.setClassNameGenerator(adviceNoteB2C -> {
            if (adviceNoteB2C.getStatus() == null) {
                return null;
            }
            return switch (adviceNoteB2C.getStatus()) {
                case INVALID, MARS_REJECTED -> "grayed";
                case MARS_ACCEPTED -> "warning";
                case INVOICE_FOUND -> "success";
                default -> null;
            };
        });

        HeaderRow headerRow = grid.appendHeaderRow();

        customerBarcodeSelect = new ComboBox<>();
        customerBarcodeSelect.setWidth(120, Unit.PIXELS);
        customerBarcodeSelect.setClearButtonVisible(true);
        customerBarcodeSelect.setAllowCustomValue(false);
        customerBarcodeSelect.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(customerBarcodeColumn).setComponent(customerBarcodeSelect);

        customerOrderRefFilter = new TextField();
        customerOrderRefFilter.setWidth(120, Unit.PIXELS);
        customerOrderRefFilter.setClearButtonVisible(true);
        customerOrderRefFilter.setValueChangeMode(ValueChangeMode.TIMEOUT);
        customerOrderRefFilter.setValueChangeTimeout(300);
        customerOrderRefFilter.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(customerOrderRefColumn).setComponent(customerOrderRefFilter);

        storeNoSelect = new ComboBox<>();
        storeNoSelect.setWidth(90, Unit.PIXELS);
        storeNoSelect.setClearButtonVisible(true);
        storeNoSelect.setAllowCustomValue(false);
        storeNoSelect.setItemLabelGenerator(mposServerUrl -> String.valueOf(mposServerUrlExpert.getStoreNo(mposServerUrl).orElse(null)));
        storeNoSelect.addValueChangeListener(event -> updateDataUsingFilters());
        storeNoSelect.setEnabled(userAuthorities.getIsAdmin());
        headerRow.getCell(storeNoColumn).setComponent(storeNoSelect);

        statusSelect = new ComboBox<>();
        statusSelect.setWidth(150, Unit.PIXELS);
        statusSelect.setClearButtonVisible(true);
        statusSelect.setAllowCustomValue(false);
        statusSelect.setItemLabelGenerator(MarsStatusUtils::getTranslation);
        statusSelect.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(statusColumn).setComponent(statusSelect);

        mposAdviceNoteIdFilter = new TextField();
        mposAdviceNoteIdFilter.setWidth(120, Unit.PIXELS);
        mposAdviceNoteIdFilter.setClearButtonVisible(true);
        mposAdviceNoteIdFilter.setValueChangeMode(ValueChangeMode.TIMEOUT);
        mposAdviceNoteIdFilter.setValueChangeTimeout(300);
        mposAdviceNoteIdFilter.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(mposAdviceNoteIdColumn).setComponent(mposAdviceNoteIdFilter);

        invoiceNoFilter = new TextField();
        invoiceNoFilter.setWidth(120, Unit.PIXELS);
        invoiceNoFilter.setClearButtonVisible(true);
        invoiceNoFilter.setValueChangeMode(ValueChangeMode.TIMEOUT);
        invoiceNoFilter.setValueChangeTimeout(300);
        invoiceNoFilter.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(invoiceNoColumn).setComponent(invoiceNoFilter);

        packingListNoFilter = new TextField();
        packingListNoFilter.setWidth(120, Unit.PIXELS);
        packingListNoFilter.setClearButtonVisible(true);
        packingListNoFilter.setValueChangeMode(ValueChangeMode.TIMEOUT);
        packingListNoFilter.setValueChangeTimeout(300);
        packingListNoFilter.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(packingListNoColumn).setComponent(packingListNoFilter);

        requestTimestampFilter = new DatePickerCZ();
        requestTimestampFilter.setValue(LocalDate.now());
        requestTimestampFilter.setRequired(true);
        requestTimestampFilter.setWidth(160, Unit.PIXELS);
        requestTimestampFilter.addValueChangeListener(event -> {
            if (!updatingFromUrl) {
                updateUrlParameter(event.getValue());
            }
            reloadData(event.getValue());
        });
        headerRow.getCell(requestTimestampColumn).setComponent(requestTimestampFilter);

        lastSentTimeFilter = new DatePickerCZ();
        lastSentTimeFilter.setWidth(160, Unit.PIXELS);
        lastSentTimeFilter.setClearButtonVisible(true);
        lastSentTimeFilter.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(lastSentTimeColumn).setComponent(lastSentTimeFilter);

        invoiceDateTimeFilter = new DatePickerCZ();
        invoiceDateTimeFilter.setWidth(160, Unit.PIXELS);
        invoiceDateTimeFilter.setClearButtonVisible(true);
        invoiceDateTimeFilter.addValueChangeListener(event -> updateDataUsingFilters());
        headerRow.getCell(invoiceDateTimeColumn).setComponent(invoiceDateTimeFilter);

        grid.setSizeFull();

        setSizeFull();
        add(grid);
    }

    private void resendAndReload() {
        reloadData(requestTimestampFilter.getValue());
    }

    private void updateDataUsingFilters() {
        Stream<OverviewDAO> filtered = all.stream();
        if (customerBarcodeSelect.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> customerBarcodeSelect.getValue().contentEquals(adviceNoteB2C.getCustomerBarcode()));
        }

        if (customerOrderRefFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getCustomerOrderRef() != null) && adviceNoteB2C.getCustomerOrderRef().toString().startsWith(customerOrderRefFilter.getValue()));
        }

        if (storeNoSelect.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> storeNoSelect.getValue().contentEquals(adviceNoteB2C.getMposServerUrl()));
        }

        if (statusSelect.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> statusSelect.getValue().equals(adviceNoteB2C.getStatus()));
        }

        if (mposAdviceNoteIdFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getLastMposAdviceNoteId() != null) && adviceNoteB2C.getLastMposAdviceNoteId().toString().startsWith(mposAdviceNoteIdFilter.getValue()));
        }

        if (invoiceNoFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getInvoiceNo() != null) && adviceNoteB2C.getInvoiceNo().toString().startsWith(invoiceNoFilter.getValue()));
        }

        if (packingListNoFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getPackingListNo() != null) && adviceNoteB2C.getPackingListNo().startsWith(packingListNoFilter.getValue()));
        }

        if (customerBarcodeSelect.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getInvoiceNo() != null) && adviceNoteB2C.getInvoiceNo().toString().startsWith(invoiceNoFilter.getValue()));
        }

        if (requestTimestampFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getRequestTimeStamp() != null) && adviceNoteB2C.getRequestTimeStamp().toLocalDate().isEqual(requestTimestampFilter.getValue()));
        }

        if (lastSentTimeFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getLastSentTime() != null) && adviceNoteB2C.getLastSentTime().toLocalDate().isEqual(lastSentTimeFilter.getValue()));
        }

        if (invoiceDateTimeFilter.getOptionalValue().isPresent()) {
            filtered = filtered.filter(adviceNoteB2C -> (adviceNoteB2C.getInvoiceDateTime() != null) && adviceNoteB2C.getInvoiceDateTime().toLocalDate().isEqual(invoiceDateTimeFilter.getValue()));
        }

        grid.setItems(filtered.sorted(Comparator.comparing(AdviceNoteB2C::getId).reversed()).toList());
        grid.getDataProvider().refreshAll();
    }

    private void updateUrlParameter(LocalDate date) {
        String queryString = date != null ? "overview?date=" + date : "";
        UI.getCurrent().getPage().getHistory().replaceState(null, queryString);
    }

    @Override
    public void afterNavigation(AfterNavigationEvent afterNavigationEvent) {
        List<String> dateParams = afterNavigationEvent.getLocation().getQueryParameters().getParameters().get("date");
        LocalDate date = LocalDate.now();
        if (dateParams != null && !dateParams.isEmpty()) {
            try {
                date = LocalDate.parse(dateParams.get(0));
            } catch (Exception ignored) {}
        }
        updatingFromUrl = true;
        requestTimestampFilter.setValue(date);
        updatingFromUrl = false;
        reloadData(date);
    }

    private void reloadData(LocalDate requestDate) {

        storeNoSelect.setItems(mposServerUrlExpert.getMposServerUrlsOrdered());

        if (userAuthorities.getIsAdmin()) {
            all = repository.getAllByRequestSince(requestDate.atStartOfDay(), requestDate.atStartOfDay().plusDays(1));
        }else{
            int usersStoreNo = userAuthorities.getUsersStoreNo().intValue();
            String usersMposServerUrl = mposServerUrlExpert.getMposServerUrl(usersStoreNo).orElse(MposServerUrlExpert.getArtificialMposServerUrl(usersStoreNo)); //if none found use artificial store to filter all messages out
            all = repository.getAllByMposServerUrlAndRequestSince(usersMposServerUrl, requestDate.atStartOfDay(), requestDate.atStartOfDay().plusDays(1));
            storeNoSelect.setValue(usersMposServerUrl); //preset user's store as only value (select is disabled)
        }



        customerBarcodeSelect.setItems(all.stream().map(OverviewDAO::getCustomerBarcode).filter(Objects::nonNull).distinct().sorted().toList());

        statusSelect.setItems(all.stream().map(OverviewDAO::getStatus).filter(Objects::nonNull).distinct().sorted().toList());

        updateDataUsingFilters();
    }

}
