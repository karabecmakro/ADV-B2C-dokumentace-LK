package cz.makro.api.advice_note.ui.view.components;

import com.vaadin.flow.component.datepicker.DatePicker;

import java.util.List;

public class DatePickerCZ extends DatePicker {

    public DatePickerCZ() {
        DatePicker.DatePickerI18n czechI18n = new DatePicker.DatePickerI18n();
        czechI18n.setFirstDayOfWeek(1);
        czechI18n.setMonthNames(List.of("Leden", "Únor", "Březen", "Duben",
                "Květen", "Červen", "Červenec", "Srpen", "Září", "Říjen", "Listopad", "Prosinec"));
        czechI18n.setWeekdays(List.of("Neděle", "Pondělí", "Úterý",
                "Středa", "Čtvrtek", "Pátek", "Sobota"));
        czechI18n.setWeekdaysShort(
                List.of("Ne", "Po", "Út", "St", "Čt", "Pá", "So"));
        czechI18n.setToday("Dnes");
        czechI18n.setCancel("Zrušit");

        this.setI18n(czechI18n);
    }
}
