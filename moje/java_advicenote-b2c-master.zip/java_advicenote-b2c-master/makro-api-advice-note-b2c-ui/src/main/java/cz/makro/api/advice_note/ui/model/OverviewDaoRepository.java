package cz.makro.api.advice_note.ui.model;

import jakarta.persistence.EntityManager;
import jakarta.persistence.Query;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Component;

import java.time.LocalDateTime;
import java.util.List;

@Component
@RequiredArgsConstructor
public class OverviewDaoRepository {

    private final EntityManager entityManager;

    public List<OverviewDAO> getAllByRequestSince(LocalDateTime requestTimeStampSinceIncluding, LocalDateTime requestTimeStampUntilIncluding) {
        String sqlWithWhereCondition = sql.replace("CONDITION_PLACEHOLDER",
                "ADVICE_NOTE.REQ_TIMESTAMP >= :requestTimeStampSince " +
                "AND ADVICE_NOTE.REQ_TIMESTAMP <= :requestTimeStampUntil"
        );
        Query query = entityManager.createNativeQuery(sqlWithWhereCondition, OverviewDAO.class);
        query.setParameter("requestTimeStampSince", requestTimeStampSinceIncluding);
        query.setParameter("requestTimeStampUntil", requestTimeStampUntilIncluding);
        return (List<OverviewDAO>) query.getResultList();
    }

    public List<OverviewDAO> getAllByMposServerUrlAndRequestSince(String mposServerUrl, LocalDateTime requestTimeStampSinceIncluding, LocalDateTime requestTimeStampUntilIncluding) {

        String sqlWithWhereCondition = sql.replace("CONDITION_PLACEHOLDER",
                "ADVICE_NOTE.MPOS_SERVER_URL = :mposServerUrl " +
                "AND ADVICE_NOTE.REQ_TIMESTAMP >= :requestTimeStampSince " +
                "AND ADVICE_NOTE.REQ_TIMESTAMP <= :requestTimeStampUntil"
        );

        Query query = entityManager.createNativeQuery(sqlWithWhereCondition, OverviewDAO.class);
        query.setParameter("mposServerUrl", mposServerUrl);
        query.setParameter("requestTimeStampSince", requestTimeStampSinceIncluding);
        query.setParameter("requestTimeStampUntil", requestTimeStampUntilIncluding);
        return (List<OverviewDAO>) query.getResultList();
    }

    private static final String sql = """
                         WITH LAST_LOGS AS (
                             SELECT B2C_ADVICE_NOTE_ID,
                                    MAX(B2C_ADVICE_NOTE_LOG_ID) AS LAST_B2C_ADVICE_NOTE_LOG_ID
                             FROM KOSIK_B2C_ADVICE_NOTE_LOG
                             GROUP BY B2C_ADVICE_NOTE_ID
                         )
                         SELECT
                                ADVICE_NOTE.B2C_ADVICE_NOTE_ID AS ID,
                                ADVICE_NOTE.CUST_BARCODE AS CUSTOMER_BARCODE,                
                                ADVICE_NOTE.HEADER_TX_NUMBER AS HEADER_TX_NUMBER,
                                ADVICE_NOTE.HEADER_REQUEST_SOURCE AS HEADER_REQUEST_SOURCE,
                                ADVICE_NOTE.OPERATOR_ID AS OPERATOR_ID,
                                ADVICE_NOTE.REQ AS REQUEST,
                                ADVICE_NOTE.RESP AS RESPONSE,                        
                                ADVICE_NOTE.RESP_TIMESTAMP AS RESPONSE_TIME_STAMP,
                                ADVICE_NOTE.REQ_TIMESTAMP AS REQUEST_TIME_STAMP,
                                ADVICE_NOTE.ADVICE_NOTE_STATUS AS STATUS,
                                ADVICE_NOTE.MPOS_SERVER_URL AS MPOS_SERVER_URL,                        
                                CAST(ADVICE_NOTE.CUST_ORDER_REF AS NUMBER(11)) AS CUST_ORDER_REF, --https://hibernate.atlassian.net/browse/HHH-18064                  
                
                                ADVICE_NOTE_LOG.RESP AS LAST_RESPONSE,
                                ADVICE_NOTE_LOG.MPOS_ADVICE_NOTE_ID AS LAST_MPOS_ADVICE_NOTE_ID,
                                ADVICE_NOTE_LOG.STATUS AS LAST_STATUS_CODE,
                                ADVICE_NOTE_LOG.SENT_TIME AS LAST_SENT_TIME,
                
                                INVOICE.TILL_NO, 
                                INVOICE.INVOICE_NO, 
                                INVOICE.PACKING_LIST AS PACKING_LIST_NO, 
                                INVOICE.INVOICE_DATE, 
                                INVOICE.INVOICE_TIME 
                
                         FROM      LAST_LOGS LAST_LOG
                                       LEFT JOIN KOSIK_B2C_ADVICE_NOTE ADVICE_NOTE ON LAST_LOG.B2C_ADVICE_NOTE_ID = ADVICE_NOTE.B2C_ADVICE_NOTE_ID
                                       LEFT JOIN KOSIK_B2C_ADVICE_NOTE_LOG ADVICE_NOTE_LOG ON LAST_LOG.LAST_B2C_ADVICE_NOTE_LOG_ID = ADVICE_NOTE_LOG.B2C_ADVICE_NOTE_LOG_ID
                                       LEFT JOIN KOSIK_B2C_INVOICE INVOICE ON LAST_LOG.B2C_ADVICE_NOTE_ID = INVOICE.B2C_ADVICE_NOTE_ID
                
                         WHERE CONDITION_PLACEHOLDER
                         
                         ORDER BY ID DESC
                """;
}
