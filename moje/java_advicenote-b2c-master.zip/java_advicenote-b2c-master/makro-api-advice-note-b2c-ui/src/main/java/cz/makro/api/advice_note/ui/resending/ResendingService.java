package cz.makro.api.advice_note.ui.resending;

import cz.makro.api.advice_note.ui.model.OverviewDAO;
import jakarta.persistence.EntityManager;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

@Slf4j
@Service
public class ResendingService {

    private final HttpClient client;
    private final String apiBaseUrl;

    public ResendingService(@Value("${app.advice-note-api-url}") String apiBaseUrl, EntityManager entityManager) {
        this.client = HttpClient.newHttpClient();
        this.apiBaseUrl = apiBaseUrl;
    }

    @Transactional
    public String resendAdviceNote(OverviewDAO adviceNoteB2C) {
        log.info("Resending adviceNote, mpos server url: " + adviceNoteB2C.getMposServerUrl() + " id: " + adviceNoteB2C.getId());
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiBaseUrl + "/api/" + adviceNoteB2C.getMposServerUrl() + "/AdviceNotes/" + adviceNoteB2C.getId() + "/resend"))
                .POST(HttpRequest.BodyPublishers.noBody())
                .build();
        try {
            client.send(request, HttpResponse.BodyHandlers.ofString());
            return "OK";
        } catch (IOException | InterruptedException e) {
            log.error("Error while resending adviceNote", e);
            return "ERROR: " + e.getMessage();
        }
    }

    @Transactional
    public String getAdviceNoteInfo(OverviewDAO adviceNoteB2C) {
        //"/api/{mposServerUrl}/CustomerBarcode/{customerBarcode}/AdviceNotes/{adviceNoteId}/invoice"
        log.info("Loading adviceNote data, mpos server url: " + adviceNoteB2C.getMposServerUrl() + " CustomerBarcode " + adviceNoteB2C.getCustomerBarcode() + " id: " + adviceNoteB2C.getLastMposAdviceNoteId());
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(apiBaseUrl + "/api/" + adviceNoteB2C.getMposServerUrl() + "/CustomerBarcode/" + adviceNoteB2C.getCustomerBarcode() + "/AdviceNotes/" + adviceNoteB2C.getLastMposAdviceNoteId() + "/invoice"))
                .GET()
                .build();
        try {
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
            return response.body();
        } catch (IOException | InterruptedException e) {
            log.error("Error while loading adviceNote data", e);
            return "ERROR: " + e.getMessage();
        }
    }

}
