package cz.makro.api.advice_note.ui.model;

import cz.makro.api.advice_note.b2c.AdviceNoteB2C;
import cz.makro.api.advice_note.base.AdviceNoteStatus;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import org.apache.commons.io.IOUtils;

import java.io.IOException;
import java.io.InputStream;
import java.io.StringWriter;
import java.nio.charset.StandardCharsets;
import java.sql.Clob;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeFormatterBuilder;
import java.time.temporal.ChronoField;

@Getter
@Setter
@EqualsAndHashCode(callSuper = true)
public class OverviewDAO extends AdviceNoteB2C {

    private static final DateTimeFormatter INVOICE_TIME_FORMATTER = new DateTimeFormatterBuilder()
            .appendOptional(DateTimeFormatter.ofPattern("Hmmss"))
            .appendOptional(DateTimeFormatter.ofPattern("mmss"))
            .parseDefaulting(ChronoField.HOUR_OF_DAY, 0)
            .toFormatter();
    private String lastResponse;
    private Long lastMposAdviceNoteId;
    private Integer lastStatusCode;
    private LocalDateTime lastSentTime;

    private Integer tillNo;
    private String invoiceNo;
    private String packingListNo;
    private LocalDateTime invoiceDateTime;

    public OverviewDAO() {
    }

    public OverviewDAO(Long id, String customerBarcode, String headerTxNumber, String headerRequestSource, Integer operatorId, Clob request, Clob response, Timestamp responseTimeStamp, Timestamp requestTimeStamp, String status, String mposServerUrl, Long customerOrderRef, Clob lastResponse, Long lastMposAdviceNoteId, Integer lastStatusCode, Timestamp lastSentTime, Integer tillNo, Long invoiceNo, String packingListNo, Timestamp invoiceDate, Integer invoiceTime) {
        super(id, customerBarcode, headerTxNumber, headerRequestSource, operatorId, clobToString(request), clobToString(response), timestampToLocalDateTime(responseTimeStamp), timestampToLocalDateTime(requestTimeStamp), AdviceNoteStatus.valueOf(status), mposServerUrl, customerOrderRef);
        this.lastResponse = clobToString(lastResponse);
        this.lastMposAdviceNoteId = lastMposAdviceNoteId;
        this.lastStatusCode = lastStatusCode;
        this.lastSentTime = timestampToLocalDateTime(lastSentTime);

        this.tillNo = tillNo;
        this.invoiceNo = tillNo != null && invoiceNo != null ? String.format("%03d/%06d", tillNo, invoiceNo) : null;
        this.packingListNo = packingListNo;
        if (invoiceDate != null && invoiceTime != null) {
            LocalTime invoiceTimeParsed = LocalTime.parse(invoiceTime.toString(), INVOICE_TIME_FORMATTER);
            this.invoiceDateTime = timestampToLocalDateTime(invoiceDate).toLocalDate().atTime(invoiceTimeParsed);
        }
    }

    private static LocalDateTime timestampToLocalDateTime(Timestamp timestamp) {
        return timestamp == null ? null : timestamp.toLocalDateTime();
    }

    private static String clobToString(Clob clob) {
        if (clob == null) {
            return null;
        }
        try (InputStream in = clob.getAsciiStream()) {
            StringWriter w = new StringWriter();
            IOUtils.copy(in, w, StandardCharsets.UTF_8);
            return w.toString();
        } catch (IOException | SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
