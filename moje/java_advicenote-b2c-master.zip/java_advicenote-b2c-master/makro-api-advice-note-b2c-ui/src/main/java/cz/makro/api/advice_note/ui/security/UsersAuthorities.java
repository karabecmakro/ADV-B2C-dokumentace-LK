package cz.makro.api.advice_note.ui.security;

import lombok.Getter;
import lombok.RequiredArgsConstructor;

@Getter
@RequiredArgsConstructor
public class UsersAuthorities {

    private final Boolean isAdmin;
    private final Long usersStoreNo;

    public static UsersAuthorities userOfStore(Long usersStoreNo) {
        return new UsersAuthorities(false, usersStoreNo);
    }

    public static UsersAuthorities admin() {
        return new UsersAuthorities(true, null);
    }

    @Override
    public String toString() {
        if (isAdmin) {
            return "Admin";
        } else {
            return "ST " + usersStoreNo;
        }
    }
}
