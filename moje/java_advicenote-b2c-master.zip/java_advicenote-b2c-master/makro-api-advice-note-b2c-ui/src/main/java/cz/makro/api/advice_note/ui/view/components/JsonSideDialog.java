package cz.makro.api.advice_note.ui.view.components;

import com.nimbusds.jose.shaded.gson.Gson;
import com.nimbusds.jose.shaded.gson.GsonBuilder;
import com.nimbusds.jose.shaded.gson.JsonObject;
import com.nimbusds.jose.shaded.gson.JsonParser;
import com.vaadin.flow.component.button.Button;
import com.vaadin.flow.component.dialog.Dialog;
import com.vaadin.flow.component.html.Div;
import com.vaadin.flow.component.html.Paragraph;
import com.vaadin.flow.component.html.Span;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.tabs.TabSheet;

import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

public class JsonSideDialog extends Dialog {

    public static final List<String> IMPORTANT_KEYS_RESPONSE = List.of("status", "body");

    public JsonSideDialog(String title, String json) {
        this(title, json, null);
    }

    public JsonSideDialog(String title, String json, boolean stringOnly) {
        Span titleSpan = new Span(title);
        titleSpan.getStyle().set("font-size", "20px");
        titleSpan.getStyle().set("font-weight", "bold");

        Button closeDialog = new Button(VaadinIcon.CLOSE.create());
        closeDialog.getStyle().setMarginLeft("auto");
        closeDialog.addClickListener(event -> close());

        TabSheet tabSheet = new TabSheet();

        tabSheet.add("Původní", new Div(createParagraph(json)));
        add(tabSheet);

        getHeader().add(titleSpan, closeDialog);

        setHeightFull();
    }

    public JsonSideDialog(String title, String json, List<String> importantKeys) {
        Span titleSpan = new Span(title);
        titleSpan.getStyle().set("font-size", "20px");
        titleSpan.getStyle().set("font-weight", "bold");

        Button closeDialog = new Button(VaadinIcon.CLOSE.create());
        closeDialog.getStyle().setMarginLeft("auto");
        closeDialog.addClickListener(event -> close());

        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        JsonObject je = (JsonObject) JsonParser.parseString(json);

        String prettyJsonStringFull = gson.toJson(je);

        AtomicBoolean filteringOccurred = new AtomicBoolean(false);

        if (importantKeys != null) {
            je.entrySet().removeIf(entry -> {
                boolean shouldRemove = !importantKeys.contains(entry.getKey());
                if (shouldRemove) {
                    filteringOccurred.set(true);
                }
                return shouldRemove;
            });
        }

        String prettyJsonStringFiltered = gson.toJson(je);

        TabSheet tabSheet = new TabSheet();
        if (filteringOccurred.get()) {
            tabSheet.add("Zjednodušený", new Div(createParagraph(prettyJsonStringFiltered))).setSelected(true);
        }
        tabSheet.add("Původní", new Div(createParagraph(prettyJsonStringFull)));
        add(tabSheet);

        getHeader().add(titleSpan, closeDialog);

        setHeightFull();
    }

    private static Paragraph createParagraph(String json) {
        Paragraph paragraph = new Paragraph(json);
        paragraph.getElement().getStyle().set("white-space", "pre");
        return paragraph;
    }
}
