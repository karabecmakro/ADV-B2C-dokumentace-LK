package cz.makro.api.advice_note.ui.model;

import cz.makro.api.advice_note.base.AdviceNoteStatus;

public class MarsStatusUtils {

    public static String getTranslation(AdviceNoteStatus status) {
        return switch (status) {
            case NEW -> "Nový";
            case VALID -> "Validní (bude odeslán)";
            case INVALID -> "Nevalidní požadavek";
            case CANCELED -> "Zrušený";
            case MARS_ACCEPTED -> "Přijato";
            case MARS_REJECTED -> "Odmítnuto";
            case INVOICE_FOUND -> "Vyfakturováno";
            default -> "?";
        };
    }
}
