package cz.makro.api.advice_note.ui.security;

import com.vaadin.flow.spring.security.VaadinWebSecurity;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.env.Environment;
import org.springframework.security.authorization.AuthorizationDecision;
import org.springframework.security.config.Customizer;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.builders.WebSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.authority.mapping.GrantedAuthoritiesMapper;
import org.springframework.security.core.session.SessionRegistry;
import org.springframework.security.core.session.SessionRegistryImpl;
import org.springframework.security.oauth2.core.oidc.user.OidcUserAuthority;
import org.springframework.security.oauth2.core.user.OAuth2UserAuthority;
import org.springframework.security.oauth2.server.resource.authentication.JwtIssuerAuthenticationManagerResolver;
import org.springframework.security.web.authentication.session.RegisterSessionAuthenticationStrategy;
import org.springframework.security.web.authentication.session.SessionAuthenticationStrategy;
import org.springframework.security.web.session.HttpSessionEventPublisher;

import java.util.Collection;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import static org.springframework.security.web.util.matcher.AntPathRequestMatcher.antMatcher;

/**
 * https://www.baeldung.com/spring-boot-keycloak
 */
@Configuration
@EnableWebSecurity
public class SecurityConfiguration extends VaadinWebSecurity {


    private static final String GROUP_MEMBERSHIP = "group_membership";
    private static final String REALM_ACCESS_CLAIM = "realm_access";
    private static final String ROLES_CLAIM = "roles";

    private final KeycloakLogoutHandler keycloakLogoutHandler;
    private final Environment environment;

    public static final Pattern ALLOWED_SECURITY_GROUP_MATCHER = Pattern.compile("/MCC (CZ|SK) ST\\d\\d - (POS COORDINATORS|POS SHIFT LEADER|POS MANAGER)");
    public final Pattern adminSecurityGroupmatcher;

    public SecurityConfiguration(KeycloakLogoutHandler keycloakLogoutHandler, Environment environment, @Value("${app.admin-group-regex}") String adminGroupRegex) {
        this.keycloakLogoutHandler = keycloakLogoutHandler;
        this.environment = environment;
        this.adminSecurityGroupmatcher = Pattern.compile(adminGroupRegex);
    }

    @Override
    protected void configure(HttpSecurity http) throws Exception {
        http
                .authorizeHttpRequests(authorizationManagerRequestMatcherRegistry -> authorizationManagerRequestMatcherRegistry
                        .requestMatchers(antMatcher("/actuator/**")).permitAll()
                        .requestMatchers(VaadinWebSecurity.getDefaultHttpSecurityPermitMatcher()).permitAll()
                        .requestMatchers(antMatcher("/*")).access((authentication, object) -> {
                            return new AuthorizationDecision(authentication.get().getAuthorities().stream()
                                    .map(grantedAuthority -> grantedAuthority.getAuthority().toUpperCase().replaceFirst("ROLE_", ""))
                                    .anyMatch(grantedAuthority ->
                                            adminSecurityGroupmatcher.matcher(grantedAuthority).matches()
                                                    || ALLOWED_SECURITY_GROUP_MATCHER.matcher(grantedAuthority).matches()
                                    ));
                        }))
                .oauth2Client(Customizer.withDefaults());

        String issuerCzUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.cz-issuer-uri");
        String issuerSkUri = environment.getProperty("spring.security.oauth2.resourceserver.jwt.sk-issuer-uri");

        http.oauth2ResourceServer((oauth2) -> oauth2.authenticationManagerResolver(JwtIssuerAuthenticationManagerResolver.fromTrustedIssuers(issuerCzUri, issuerSkUri)));
        http.oauth2Login(httpSecurityOAuth2LoginConfigurer -> httpSecurityOAuth2LoginConfigurer.defaultSuccessUrl("/overview", true)
                .userInfoEndpoint(userInfoEndpointConfig -> userInfoEndpointConfig.userAuthoritiesMapper(userAuthoritiesMapperForKeycloak()))
        );
        http.logout(logout -> logout.addLogoutHandler(keycloakLogoutHandler).logoutSuccessUrl("/"));
        super.configure(http);
    }

    @Override
    protected void configure(WebSecurity web) throws Exception {
        web.ignoring().requestMatchers(VaadinWebSecurity.getDefaultWebSecurityIgnoreMatcher());
    }

    @Bean
    public SessionRegistry sessionRegistry() {
        return new SessionRegistryImpl();
    }

    @Bean
    protected SessionAuthenticationStrategy sessionAuthenticationStrategy() {
        return new RegisterSessionAuthenticationStrategy(sessionRegistry());
    }

    @Bean
    public HttpSessionEventPublisher httpSessionEventPublisher() {
        return new HttpSessionEventPublisher();
    }

    @Bean
    public GrantedAuthoritiesMapper userAuthoritiesMapperForKeycloak() {
        return authorities -> {
            Set<GrantedAuthority> mappedAuthorities = new HashSet<>();
            var authority = authorities.iterator().next();
            boolean isOidc = authority instanceof OidcUserAuthority;

            if (isOidc) {
                var oidcUserAuthority = (OidcUserAuthority) authority;
                var userInfo = oidcUserAuthority.getUserInfo();

                // Tokens can be configured to return roles under
                // Groups or REALM ACCESS hence have to check both
                if (userInfo.hasClaim(REALM_ACCESS_CLAIM)) {
                    var realmAccess = userInfo.getClaimAsMap(REALM_ACCESS_CLAIM);
                    var roles = (Collection<String>) realmAccess.get(ROLES_CLAIM);
                    mappedAuthorities.addAll(generateAuthoritiesFromClaim(roles));
                } else if (userInfo.hasClaim(GROUP_MEMBERSHIP)) {
                    Collection<String> roles = userInfo.getClaim(GROUP_MEMBERSHIP);
                    mappedAuthorities.addAll(generateAuthoritiesFromClaim(roles));
                }
            } else {
                var oauth2UserAuthority = (OAuth2UserAuthority) authority;
                Map<String, Object> userAttributes = oauth2UserAuthority.getAttributes();

                if (userAttributes.containsKey(REALM_ACCESS_CLAIM)) {
                    Map<String, Object> realmAccess = (Map<String, Object>) userAttributes.get(REALM_ACCESS_CLAIM);
                    Collection<String> roles = (Collection<String>) realmAccess.get(ROLES_CLAIM);
                    mappedAuthorities.addAll(generateAuthoritiesFromClaim(roles));
                }
            }
            return mappedAuthorities;
        };
    }

    Collection<GrantedAuthority> generateAuthoritiesFromClaim(Collection<String> roles) {
        return roles.stream().map(role -> new SimpleGrantedAuthority("ROLE_" + role)).collect(
                Collectors.toList());
    }
}
