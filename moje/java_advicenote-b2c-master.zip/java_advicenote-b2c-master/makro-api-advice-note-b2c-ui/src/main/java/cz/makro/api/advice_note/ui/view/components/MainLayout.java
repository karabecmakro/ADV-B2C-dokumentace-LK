package cz.makro.api.advice_note.ui.view.components;

import com.vaadin.flow.component.applayout.AppLayout;
import com.vaadin.flow.component.applayout.DrawerToggle;
import com.vaadin.flow.component.html.H1;
import com.vaadin.flow.component.html.H2;
import com.vaadin.flow.component.icon.VaadinIcon;
import com.vaadin.flow.component.orderedlayout.Scroller;
import com.vaadin.flow.component.sidenav.SideNav;
import com.vaadin.flow.component.sidenav.SideNavItem;
import com.vaadin.flow.router.Layout;
import com.vaadin.flow.theme.lumo.LumoUtility;
import cz.makro.api.advice_note.ui.security.UserSecurityInfoService;
import cz.makro.api.advice_note.ui.view.OverviewView;
import jakarta.annotation.security.PermitAll;

@Layout
@PermitAll
public class MainLayout extends AppLayout {

    public MainLayout(UserSecurityInfoService userSecurityInfoService) {
        DrawerToggle toggle = new DrawerToggle();
        addToNavbar(toggle);

        H1 title = new H1("Košík B2C (vyberte datum v poli \"Přijetí AN z Košíku\")");
        title.getStyle().set("font-size", "var(--lumo-font-size-l)")
                .set("margin", "0");
        addToNavbar(title);

        H2 userAndRole = new H2(userSecurityInfoService.getUserFirstNameAndLastName() + " (" + userSecurityInfoService.getUserAuthorities() + ")");
        userAndRole.getStyle().set("font-size", "var(--lumo-font-size-l)");
        userAndRole.getStyle().set("margin-left", "auto");
        userAndRole.getStyle().set("padding", "15px");
        addToNavbar(userAndRole);

        SideNav nav = getSideNav();

        Scroller scroller = new Scroller(nav);
        scroller.setClassName(LumoUtility.Padding.SMALL);

        addToDrawer(scroller);
        setDrawerOpened(false);
    }

    private SideNav getSideNav() {
        SideNav sideNav = new SideNav();
        sideNav.addItem(
                new SideNavItem("Přehled", OverviewView.class, VaadinIcon.DASHBOARD.create())
//                new SideNavItem("Z Košíku", IncommingMessagesView.class, VaadinIcon.INBOX.create()),
//                new SideNavItem("Do MARSu", OutcommingMessagesView.class, VaadinIcon.OUTBOX.create()),
//                new SideNavItem("Faktury", InvoicesView.class, VaadinIcon.INVOICE.create())
        );
        return sideNav;
    }
}
