package cz.makro.api.advice_note.b2c;

import cz.makro.api.advice_note.base.AdviceNoteRepository;

public interface AdviceNoteB2CRepository extends AdviceNoteRepository<AdviceNoteB2C> {

}
