package cz.makro.api.advice_note.b2c;

import cz.makro.api.advice_note.base.AdviceNoteItem;
import jakarta.persistence.*;
import lombok.EqualsAndHashCode;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;


@Table(name = "KOSIK_B2C_ADVICE_NOTE_LINE")
@Entity
@Getter
@Setter
@EqualsAndHashCode(of = "id", callSuper = false)
@ToString(callSuper = true)
public class AdviceNoteB2CItem extends AdviceNoteItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "B2C_ADVICE_NOTE_LINE_ID")
    private Long id;

}
