package cz.makro.api.advice_note.b2c.log;


import cz.makro.api.advice_note.base.log.AdviceNoteLog;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "KOSIK_B2C_ADVICE_NOTE_LOG")
@Getter
@Setter
@EqualsAndHashCode(of = "id", callSuper = false)
@ToString
@NoArgsConstructor(access = AccessLevel.PROTECTED)
public class AdviceNoteB2CLog extends AdviceNoteLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "B2C_ADVICE_NOTE_LOG_ID")
    private Long id;

    @Column(name = "B2C_ADVICE_NOTE_ID")
    private Long adviceNoteId;

    public AdviceNoteB2CLog(Long adviceNoteId) {
        this.adviceNoteId = adviceNoteId;
    }
}
