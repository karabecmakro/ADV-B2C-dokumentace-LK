package cz.makro.api.advice_note.base.log;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.util.Optional;

@NoRepositoryBean
public interface AdviceNoteLogRepository<T extends AdviceNoteLog> extends JpaRepository<T, Long> {

    Optional<T> findFirstByAdviceNoteIdOrderBySentTimeDesc(Long adviceNoteId);

}
