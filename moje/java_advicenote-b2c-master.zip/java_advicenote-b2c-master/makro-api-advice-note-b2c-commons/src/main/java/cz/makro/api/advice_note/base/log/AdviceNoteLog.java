package cz.makro.api.advice_note.base.log;


import jakarta.persistence.Column;
import jakarta.persistence.Lob;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;
import org.apache.commons.lang3.StringUtils;

import java.time.LocalDateTime;

@Getter
@Setter
@ToString
@MappedSuperclass
public abstract class AdviceNoteLog {

    @Lob
    @Column(name = "REQ")
    private String request;
    @Lob
    @Column(name = "RESP")
    private String response;
    @Column
    private Long mposAdviceNoteId;
    @Column(name = "STATUS")
    private Integer statusCode;
    private LocalDateTime sentTime;
    @Column(name = "ERR")
    private String errors;

    public void setErrors(String errors) {
        this.errors = StringUtils.abbreviate(errors, 4000);
    }
}
