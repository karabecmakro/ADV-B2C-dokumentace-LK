package cz.makro.api.advice_note.base;

import jakarta.persistence.Column;
import jakarta.persistence.MappedSuperclass;
import lombok.Getter;
import lombok.Setter;
import lombok.ToString;

import java.math.BigDecimal;

@ToString
@Getter
@Setter
@MappedSuperclass
public abstract class AdviceNoteItem {

    @Column(name = "SEQ_NUMBER")
    private String sequenceNumber;
    private String barcodeOrGtin;
    private String gtin;
    private String lotNumber;
    private String barcode;
    @Column(name = "QTY")
    private BigDecimal quantity;
    private BigDecimal weight;
    private String externalBarcode;

    private String szArticleDetails;
}
