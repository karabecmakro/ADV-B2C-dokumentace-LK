package cz.makro.api.advice_note.base;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;


@Getter
@Setter
@ToString
@MappedSuperclass
@NoArgsConstructor
@AllArgsConstructor
public abstract class AdviceNote {

    @Column(name = "CUST_BARCODE")
    private String customerBarcode;
    private String headerTxNumber;
    private String headerRequestSource;
    private Integer operatorId;
    @Lob
    @Column(name = "REQ")
    private String request;
    @Lob
    @Column(name = "RESP")
    private String response;
    @Column(name = "RESP_TIMESTAMP")
    private LocalDateTime responseTimeStamp;
    @Column(name = "REQ_TIMESTAMP")
    private LocalDateTime requestTimeStamp;
    @Column(name = "ADVICE_NOTE_STATUS")
    @Enumerated(EnumType.STRING)
    private AdviceNoteStatus status;
    private String mposServerUrl;
}
