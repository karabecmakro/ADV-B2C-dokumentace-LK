package cz.makro.api.advice_note.base;

import java.util.Set;

public enum AdviceNoteStatus {
    NEW,
    VALID,
    INVALID,
    MARS_ACCEPTED,
    MARS_REJECTED,
    INVOICE_FOUND,
    CANCELED;

    private static final Set<AdviceNoteStatus> CANCELABLE_STATES = Set.of(NEW, VALID, INVALID, MARS_REJECTED);

    public static boolean isCancelable(AdviceNoteStatus status) {
        return CANCELABLE_STATES.contains(status);
    }

}
