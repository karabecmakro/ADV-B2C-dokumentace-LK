package cz.makro.api.advice_note.base;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.repository.NoRepositoryBean;

import java.time.LocalDateTime;
import java.util.List;

@NoRepositoryBean
public interface AdviceNoteRepository<T extends AdviceNote> extends JpaRepository<T, Long> {

    List<T> findAllByStatusAndRequestTimeStampAfter(AdviceNoteStatus status, LocalDateTime requestTimeStamp);

}
