package cz.makro.api.advice_note.b2c.log;

import cz.makro.api.advice_note.base.log.AdviceNoteLogRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface AdviceNoteB2CLogRepository extends AdviceNoteLogRepository<AdviceNoteB2CLog> {

}
