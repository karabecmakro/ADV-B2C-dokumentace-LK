package cz.makro.api.advice_note.b2c;

import cz.makro.api.advice_note.base.AdviceNote;
import cz.makro.api.advice_note.base.AdviceNoteStatus;
import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.List;


@Getter
@Setter
@Table(name = "KOSIK_B2C_ADVICE_NOTE")
@Entity
@EqualsAndHashCode(of = "id", callSuper = false)
@NoArgsConstructor(access = AccessLevel.PUBLIC)
@AllArgsConstructor(access = AccessLevel.PUBLIC)
public class AdviceNoteB2C extends AdviceNote {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "B2C_ADVICE_NOTE_ID")
    private Long id;

    @OneToMany(cascade = CascadeType.ALL)
    @JoinColumn(name = "B2C_ADVICE_NOTE_ID", referencedColumnName = "B2C_ADVICE_NOTE_ID", nullable = false)
    private List<AdviceNoteB2CItem> adviceNoteItems;

    @Column(name = "CUST_ORDER_REF")
    private Long customerOrderRef;

    public AdviceNoteB2C(Long id, String customerBarcode, String headerTxNumber, String headerRequestSource, Integer operatorId, String request, String response, LocalDateTime responseTimeStamp, LocalDateTime requestTimeStamp, AdviceNoteStatus status, String mposServerUrl, Long customerOrderRef) {
        super(customerBarcode, headerTxNumber, headerRequestSource, operatorId, request, response, responseTimeStamp, requestTimeStamp, status, mposServerUrl);
        this.id = id;
        this.customerOrderRef = customerOrderRef;
    }
}
